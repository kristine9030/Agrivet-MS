
package agrivetmanagementsystem;

/**
 *
 * @author Kristine
 */
public class AgrivetManagementSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
