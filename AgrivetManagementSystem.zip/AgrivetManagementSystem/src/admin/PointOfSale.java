package admin;

import admin.DatabaseConnection;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.RoundingMode;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.UIManager;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.JTextField;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JRadioButton;



public class PointOfSale extends javax.swing.JFrame {

    private Connection conn;
    private BigDecimal totalPrice = BigDecimal.ZERO; // Running total for the cart
    List<CartItem> cartItems = new ArrayList<>();

    public PointOfSale() {
        initComponents();
        applyRightShadow(header);
        populateProductsTable(productsTable);
       populateServiceTable(); 
       populateReservationsUsingProcedure();

        productsPanel.setLayout(new BoxLayout(productsPanel, BoxLayout.Y_AXIS));
        servicePanel.setLayout(new BoxLayout(servicePanel, BoxLayout.Y_AXIS)); // Make sure layout is set


        try {
            UIManager.setLookAndFeel(new FlatLightLaf()); // or FlatIntelliJLaf(), FlatDarkLaf(), etc.
        } catch (Exception e) {
            e.printStackTrace();
        }

        this.totalTxt = totalTxt;

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        header = new javax.swing.JPanel();
        SidebarMenu = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        paymentPanel1 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        totalLabelField = new javax.swing.JTextField();
        nameTxt4 = new javax.swing.JLabel();
        nameTxt7 = new javax.swing.JLabel();
        changeTextField1 = new javax.swing.JTextField();
        paybutton3 = new javax.swing.JButton();
        paybutton4 = new javax.swing.JButton();
        paybutton5 = new javax.swing.JButton();
        paymentTextField1 = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        serviceTable = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        reservationsTable = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        servicePanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        scrollPane = new javax.swing.JScrollPane();
        productsTable = new javax.swing.JTable();
        paymentPanel = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        totalTxt = new javax.swing.JTextField();
        nameTxt3 = new javax.swing.JLabel();
        paymentTextField = new javax.swing.JTextField();
        nameTxt6 = new javax.swing.JLabel();
        changeTextField = new javax.swing.JTextField();
        voidall = new javax.swing.JButton();
        paybutton1 = new javax.swing.JButton();
        paybutton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        productsPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(238, 239, 238));

        header.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout headerLayout = new javax.swing.GroupLayout(header);
        header.setLayout(headerLayout);
        headerLayout.setHorizontalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        headerLayout.setVerticalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        SidebarMenu.setBackground(new java.awt.Color(0, 96, 50));

        jButton1.setBackground(new java.awt.Color(0, 96, 50));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home (6).png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 51, 0));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/box-open.png"))); // NOI18N
        jButton2.setBorder(null);

        jButton4.setBackground(new java.awt.Color(0, 96, 50));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/newspaper.png"))); // NOI18N
        jButton4.setBorder(null);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(0, 96, 50));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/point-of-sale-bill.png"))); // NOI18N
        jButton5.setBorder(null);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(0, 96, 50));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/inventory-alt.png"))); // NOI18N
        jButton6.setBorder(null);

        jButton7.setBackground(new java.awt.Color(0, 96, 50));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/calendar-day.png"))); // NOI18N
        jButton7.setBorder(null);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SidebarMenuLayout = new javax.swing.GroupLayout(SidebarMenu);
        SidebarMenu.setLayout(SidebarMenuLayout);
        SidebarMenuLayout.setHorizontalGroup(
            SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SidebarMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(SidebarMenuLayout.createSequentialGroup()
                        .addGroup(SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE)
                            .addComponent(jButton7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        SidebarMenuLayout.setVerticalGroup(
            SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SidebarMenuLayout.createSequentialGroup()
                .addContainerGap(198, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(137, 137, 137))
        );

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        paymentPanel1.setBackground(new java.awt.Color(225, 225, 225));
        paymentPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        paymentPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel22.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 0, 0));
        jLabel22.setText("Total ");

        totalLabelField.setBackground(new java.awt.Color(51, 51, 51));
        totalLabelField.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        totalLabelField.setForeground(new java.awt.Color(255, 204, 0));
        totalLabelField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalLabelFieldActionPerformed(evt);
            }
        });

        nameTxt4.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        nameTxt4.setForeground(new java.awt.Color(51, 51, 51));
        nameTxt4.setText("Amount Pay: ");

        nameTxt7.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        nameTxt7.setForeground(new java.awt.Color(51, 51, 51));
        nameTxt7.setText("Change: ");

        changeTextField1.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        changeTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeTextField1ActionPerformed(evt);
            }
        });

        paybutton3.setBackground(new java.awt.Color(168, 28, 28));
        paybutton3.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        paybutton3.setForeground(new java.awt.Color(255, 255, 255));
        paybutton3.setText("VOID ALL");
        paybutton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paybutton3ActionPerformed(evt);
            }
        });

        paybutton4.setBackground(new java.awt.Color(0, 153, 51));
        paybutton4.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        paybutton4.setForeground(new java.awt.Color(255, 255, 255));
        paybutton4.setText("PAY  ");
        paybutton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paybutton4ActionPerformed(evt);
            }
        });

        paybutton5.setBackground(new java.awt.Color(168, 28, 28));
        paybutton5.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        paybutton5.setForeground(new java.awt.Color(255, 255, 255));
        paybutton5.setText("VOID");
        paybutton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paybutton5ActionPerformed(evt);
            }
        });

        paymentTextField1.setBackground(new java.awt.Color(51, 51, 51));
        paymentTextField1.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        paymentTextField1.setForeground(new java.awt.Color(255, 204, 0));
        paymentTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paymentTextField1ActionPerformed(evt);
            }
        });
        paymentTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                paymentTextField1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout paymentPanel1Layout = new javax.swing.GroupLayout(paymentPanel1);
        paymentPanel1.setLayout(paymentPanel1Layout);
        paymentPanel1Layout.setHorizontalGroup(
            paymentPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paymentPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(paymentPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(paybutton4, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(paymentPanel1Layout.createSequentialGroup()
                        .addComponent(paybutton5, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(paybutton3, javax.swing.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE)
                        .addGap(16, 16, 16)))
                .addGroup(paymentPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(paymentPanel1Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jLabel22))
                    .addComponent(nameTxt4)
                    .addGroup(paymentPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(nameTxt7)))
                .addGap(16, 16, 16)
                .addGroup(paymentPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(paymentPanel1Layout.createSequentialGroup()
                        .addGroup(paymentPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(totalLabelField)
                            .addComponent(changeTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(paymentTextField1))
                .addContainerGap())
        );
        paymentPanel1Layout.setVerticalGroup(
            paymentPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paymentPanel1Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(paymentPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(paymentPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(paymentPanel1Layout.createSequentialGroup()
                            .addComponent(totalLabelField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(paymentTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(8, 8, 8)
                            .addComponent(changeTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(paymentPanel1Layout.createSequentialGroup()
                            .addGap(4, 4, 4)
                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(10, 10, 10)
                            .addComponent(nameTxt4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(10, 10, 10)
                            .addComponent(nameTxt7)))
                    .addGroup(paymentPanel1Layout.createSequentialGroup()
                        .addComponent(paybutton4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(paymentPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(paybutton3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(paybutton5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.add(paymentPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(567, 530, 572, -1));

        jScrollPane2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jScrollPane2MouseClicked(evt);
            }
        });

        serviceTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Service ID", "Services", "Charge", "Service Type"
            }
        ));
        serviceTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                serviceTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(serviceTable);

        jScrollPane3.setViewportView(jScrollPane2);

        jPanel3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 550, 250));

        reservationsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Reservation ID", "Date", "Name", "Contact", "Services", "Home Service", "Place"
            }
        ));
        jScrollPane4.setViewportView(reservationsTable);

        jPanel3.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 550, 270));

        servicePanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setText("SERVICES CART");

        javax.swing.GroupLayout servicePanelLayout = new javax.swing.GroupLayout(servicePanel);
        servicePanel.setLayout(servicePanelLayout);
        servicePanelLayout.setHorizontalGroup(
            servicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, servicePanelLayout.createSequentialGroup()
                .addContainerGap(221, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(175, 175, 175))
        );
        servicePanelLayout.setVerticalGroup(
            servicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(servicePanelLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel2)
                .addContainerGap(455, Short.MAX_VALUE))
        );

        jScrollPane5.setViewportView(servicePanel);

        jPanel3.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 30, 570, 490));

        jTextField1.setText("SERVICES TABLE");
        jPanel3.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 20, -1, -1));

        jTextField2.setText("RESERVATIONS TABLE ");
        jPanel3.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 310, -1, -1));

        jTabbedPane1.addTab("SERVICES POS", jPanel3);

        scrollPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                scrollPaneMouseClicked(evt);
            }
        });

        productsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Product ID", "Name", "Stocks", "Price"
            }
        ));
        productsTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                productsTableMouseClicked(evt);
            }
        });
        scrollPane.setViewportView(productsTable);

        paymentPanel.setBackground(new java.awt.Color(225, 225, 225));
        paymentPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        paymentPanel.setForeground(new java.awt.Color(255, 255, 255));

        jLabel21.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 0, 0));
        jLabel21.setText("Total ");

        totalTxt.setBackground(new java.awt.Color(51, 51, 51));
        totalTxt.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        totalTxt.setForeground(new java.awt.Color(255, 204, 0));
        totalTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalTxtActionPerformed(evt);
            }
        });

        nameTxt3.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        nameTxt3.setForeground(new java.awt.Color(51, 51, 51));
        nameTxt3.setText("Amount Pay: ");

        paymentTextField.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        paymentTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paymentTextFieldActionPerformed(evt);
            }
        });
        paymentTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                paymentTextFieldKeyPressed(evt);
            }
        });

        nameTxt6.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        nameTxt6.setForeground(new java.awt.Color(51, 51, 51));
        nameTxt6.setText("Change: ");

        changeTextField.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        changeTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeTextFieldActionPerformed(evt);
            }
        });

        voidall.setBackground(new java.awt.Color(168, 28, 28));
        voidall.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        voidall.setForeground(new java.awt.Color(255, 255, 255));
        voidall.setText("VOID ALL");
        voidall.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voidallActionPerformed(evt);
            }
        });

        paybutton1.setBackground(new java.awt.Color(0, 153, 51));
        paybutton1.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        paybutton1.setForeground(new java.awt.Color(255, 255, 255));
        paybutton1.setText("PAY  ");
        paybutton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paybutton1ActionPerformed(evt);
            }
        });

        paybutton2.setBackground(new java.awt.Color(168, 28, 28));
        paybutton2.setFont(new java.awt.Font("Poppins", 1, 18)); // NOI18N
        paybutton2.setForeground(new java.awt.Color(255, 255, 255));
        paybutton2.setText("VOID");
        paybutton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paybutton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout paymentPanelLayout = new javax.swing.GroupLayout(paymentPanel);
        paymentPanel.setLayout(paymentPanelLayout);
        paymentPanelLayout.setHorizontalGroup(
            paymentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paymentPanelLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(paymentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(paybutton1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(paymentPanelLayout.createSequentialGroup()
                        .addComponent(paybutton2, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(voidall, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(16, 16, 16)))
                .addGroup(paymentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(paymentPanelLayout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jLabel21))
                    .addComponent(nameTxt3)
                    .addGroup(paymentPanelLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(nameTxt6)))
                .addGap(16, 16, 16)
                .addGroup(paymentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(totalTxt)
                    .addComponent(paymentTextField)
                    .addComponent(changeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        paymentPanelLayout.setVerticalGroup(
            paymentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paymentPanelLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(paymentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(paymentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(paymentPanelLayout.createSequentialGroup()
                            .addComponent(totalTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(10, 10, 10)
                            .addComponent(paymentTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(10, 10, 10)
                            .addComponent(changeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(paymentPanelLayout.createSequentialGroup()
                            .addGap(4, 4, 4)
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(10, 10, 10)
                            .addComponent(nameTxt3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(10, 10, 10)
                            .addComponent(nameTxt6)))
                    .addGroup(paymentPanelLayout.createSequentialGroup()
                        .addComponent(paybutton1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(paymentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(voidall, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(paybutton2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setText("PRODUCT GATHERED");

        javax.swing.GroupLayout productsPanelLayout = new javax.swing.GroupLayout(productsPanel);
        productsPanel.setLayout(productsPanelLayout);
        productsPanelLayout.setHorizontalGroup(
            productsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(productsPanelLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(365, Short.MAX_VALUE))
        );
        productsPanelLayout.setVerticalGroup(
            productsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(productsPanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addContainerGap(550, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(productsPanel);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(scrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 541, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(paymentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(paymentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addComponent(scrollPane)
                .addContainerGap())
        );

        jTabbedPane1.addTab("PRODUCTS POS ", jPanel2);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(SidebarMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(header, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1145, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 16, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(SidebarMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(header, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void paybutton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paybutton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_paybutton2ActionPerformed
    private void updateProductStock(Connection conn, int productId, int quantityPurchased) throws SQLException {
        String updateStockSQL = "UPDATE products SET stocks = stocks - ? WHERE product_id = ?";
        try (PreparedStatement updateStockStmt = conn.prepareStatement(updateStockSQL)) {
            updateStockStmt.setInt(1, quantityPurchased);  // Set the quantity to decrease
            updateStockStmt.setInt(2, productId);  // Set the product ID
            updateStockStmt.executeUpdate();  // Execute the update
        }
    }
    private void paybutton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paybutton1ActionPerformed

        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false); // Transaction block

            // Step 1: Insert into `sales` table
            String insertSaleSQL = "INSERT INTO sales (total_amount, amount_paid, change_due, sale_date) VALUES (?, ?, ?, NOW())";
            PreparedStatement saleStmt = conn.prepareStatement(insertSaleSQL, Statement.RETURN_GENERATED_KEYS);

            BigDecimal totalAmount = BigDecimal.ZERO;
            BigDecimal amountPaid;

            try {
                amountPaid = new BigDecimal(paymentTextField.getText().trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid payment amount.");
                return;
            }

            // Collect cards
            List<JPanel> productCards = new ArrayList<>();
            for (Component comp : productsPanel.getComponents()) {
                if (comp instanceof JPanel) {
                    productCards.add((JPanel) comp);
                }
            }

            if (productCards.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please select at least 1 item.");
                return;
            }

            // First pass: calculate total
            for (JPanel card : productCards) {
                JPanel centerPanel = (JPanel) card.getComponent(1);
                Component[] labels = centerPanel.getComponents();

                int qty = Integer.parseInt(((JLabel) labels[2]).getText().replace("Quantity: ", "").trim());
                BigDecimal price = new BigDecimal(((JLabel) labels[3]).getText().replace("Price: ₱", "").trim());
                totalAmount = totalAmount.add(price.multiply(BigDecimal.valueOf(qty)));
            }

            BigDecimal changeDue = amountPaid.subtract(totalAmount);

            saleStmt.setBigDecimal(1, totalAmount);
            saleStmt.setBigDecimal(2, amountPaid);
            saleStmt.setBigDecimal(3, changeDue);
            saleStmt.executeUpdate();

            // Get sale_id
            ResultSet rs = saleStmt.getGeneratedKeys();
            int saleId;
            if (rs.next()) {
                saleId = rs.getInt(1);
            } else {
                conn.rollback();
                JOptionPane.showMessageDialog(null, "Failed to create sale record.");
                return;
            }

            // Step 2: Insert into `sales_items`
            String insertItemSQL = "INSERT INTO sales_items (sale_id, product_id, name, quantity, price, total) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement itemStmt = conn.prepareStatement(insertItemSQL);

            for (JPanel card : productCards) {
                JPanel centerPanel = (JPanel) card.getComponent(1);
                Component[] labels = centerPanel.getComponents();

                int productId = Integer.parseInt(((JLabel) labels[1]).getText().replace("Product ID: ", "").trim());
                String name = ((JLabel) labels[0]).getText().replace("Name: ", "").trim();
                int qty = Integer.parseInt(((JLabel) labels[2]).getText().replace("Quantity: ", "").trim());
                BigDecimal price = new BigDecimal(((JLabel) labels[3]).getText().replace("Price: ₱", "").trim());
                BigDecimal total = price.multiply(BigDecimal.valueOf(qty));

                itemStmt.setInt(1, saleId);
                itemStmt.setInt(2, productId);
                itemStmt.setString(3, name);
                itemStmt.setInt(4, qty);
                itemStmt.setBigDecimal(5, price);
                itemStmt.setBigDecimal(6, total);

                itemStmt.addBatch();
            }

            itemStmt.executeBatch(); // Insert all items
            conn.commit();

            JOptionPane.showMessageDialog(null, "Payment Successful!");
            ReceiptGenerator receiptGenerator = new ReceiptGenerator();
            String loggedInUser = null;
            receiptGenerator.onPaymentSuccess(saleId, conn, loggedInUser);
         

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error during payment: " + ex.getMessage());
        }

    }//GEN-LAST:event_paybutton1ActionPerformed


    private void voidallActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voidallActionPerformed
                                        
    voidAllItems();
    }//GEN-LAST:event_voidallActionPerformed

    private void changeTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeTextFieldActionPerformed
        // calculateChange();
    }//GEN-LAST:event_changeTextFieldActionPerformed

    private void totalTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalTxtActionPerformed
        //computeTotalAmount();
    }//GEN-LAST:event_totalTxtActionPerformed

    private void scrollPaneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_scrollPaneMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_scrollPaneMouseClicked

    private void productsTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_productsTableMouseClicked
                                          
    int selectedRow = productsTable.getSelectedRow();
    if (selectedRow != -1) {
        Object pidObj = productsTable.getValueAt(selectedRow, 0);
        Object nameObj = productsTable.getValueAt(selectedRow, 1);
        Object stockObj = productsTable.getValueAt(selectedRow, 2);
        Object priceObj = productsTable.getValueAt(selectedRow, 3);

        if (pidObj != null && nameObj != null && stockObj != null && priceObj != null) {
            String productId = pidObj.toString();
            String name = nameObj.toString();
            int stocks = Integer.parseInt(stockObj.toString());
            BigDecimal price = new BigDecimal(priceObj.toString());

            // Prompt the user for quantity with a more user-friendly dialog
            String qtyInput = JOptionPane.showInputDialog(
                    null,
                    "Enter quantity for \"" + name + "\" (Available: " + stocks + "):",
                    "Select Quantity",
                    JOptionPane.QUESTION_MESSAGE
            );

            if (qtyInput != null) {
                try {
                    int quantity = Integer.parseInt(qtyInput);
                    if (quantity > 0 && quantity <= stocks) {
                        // Update stock in database
                        updateStockInDatabase(productId, quantity);
                        populateProductsTable(productsTable);

                        // Add the product card to the panel
                        addProductCard(productsPanel, productId, name, quantity, price);
                    } else {
                        JOptionPane.showMessageDialog(null,
                                "No sufficient stocks",
                                "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null,
                            "Please enter a valid number.",
                            "Invalid Input", JOptionPane.WARNING_MESSAGE);
                }
            }
        }
    }
}

// Method to update the stock in the database
private void updateStockInDatabase(String productId, int quantity) {
    // Replace with actual database connection code
    try (Connection conn = DatabaseConnection.getConnection()) {
        String updateQuery = "UPDATE products SET stocks = stocks - ? WHERE product_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(updateQuery)) {
            stmt.setInt(1, quantity);  // Set the quantity to be subtracted
            stmt.setString(2, productId);  // Set the product ID
            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated == 0) {
                JOptionPane.showMessageDialog(null,
                        "Error: Product not found or stock update failed.",
                        "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null,
                "Error updating stock in database: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_productsTableMouseClicked

 
    private void paybutton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paybutton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_paybutton5ActionPerformed

    private void paybutton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paybutton4ActionPerformed
        showCustomerSelectionDialog();
    }//GEN-LAST:event_paybutton4ActionPerformed

    private void paybutton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paybutton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_paybutton3ActionPerformed

    private void changeTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_changeTextField1ActionPerformed

    private void totalLabelFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalLabelFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_totalLabelFieldActionPerformed

    private void jScrollPane2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jScrollPane2MouseClicked

    private void serviceTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_serviceTableMouseClicked
        int row = serviceTable.getSelectedRow();
        if (row != -1) {
            String serviceId = serviceTable.getValueAt(row, 0).toString();
            String serviceName = serviceTable.getValueAt(row, 1).toString();
            BigDecimal price = new BigDecimal(serviceTable.getValueAt(row, 2).toString());

            System.out.println("Clicked service: " + serviceName); // 👈 DEBUG

            String qtyStr = JOptionPane.showInputDialog("Enter quantity: (eg. no. of animals)");
            if (qtyStr != null && qtyStr.matches("\\d+")) {
                int qty = Integer.parseInt(qtyStr);
                System.out.println("Calling addServiceCard..."); // 👈 DEBUG

                addServiceCard(servicePanel, serviceId, serviceName, qty, price);
            }
        }
    }//GEN-LAST:event_serviceTableMouseClicked

    private void paymentTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_paymentTextFieldKeyPressed
        paymentTextField.addActionListener(e -> computeChange());

    }//GEN-LAST:event_paymentTextFieldKeyPressed

    private void paymentTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paymentTextFieldActionPerformed
           
    }//GEN-LAST:event_paymentTextFieldActionPerformed

    private void paymentTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paymentTextField1ActionPerformed
        computeChangeReservation();
    }//GEN-LAST:event_paymentTextField1ActionPerformed

    private void paymentTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_paymentTextField1KeyPressed
       
    }//GEN-LAST:event_paymentTextField1KeyPressed

    public void populateProductsTable(JTable productsTable) {
        String query = "SELECT product_id, name, stocks, selling_price FROM products";

        try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(query); ResultSet rs = pst.executeQuery()) {

            // Column headers for the table
            String[] columnNames = {"Product ID", "Name", "Stocks", "Price"};
            DefaultTableModel model = new DefaultTableModel(columnNames, 0);

            // Populate table model with rows from ResultSet
            while (rs.next()) {
                Object[] row = {
                    rs.getString("product_id"),
                    rs.getString("name"),
                    rs.getInt("stocks"),
                    rs.getBigDecimal("selling_price")
                };
                model.addRow(row);
            }

            // Set the model to your JTable
            productsTable.setModel(model);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading product inventory: " + e.getMessage());
        }
    }

    public void addProductCard(JPanel productPanel, String productId, String name, int quantity, BigDecimal price) {
        // Calculate the total price for this item
        BigDecimal itemTotal = price.multiply(new BigDecimal(quantity));

        // Update the running total
        totalPrice = totalPrice.add(itemTotal);

        // Create the product card
        JPanel card = new JPanel(new BorderLayout(10, 0)); // space between icon and text
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        card.setPreferredSize(new Dimension(360, 120));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));

        // Emoji icon based on product type
        String emoji = name.contains("vaccine") ? "💉"
                : name.contains("feed") ? "🌾"
                : name.contains("vitamin") ? "💊"
                : name.contains("seed") ? "🌱" : "📦"; // Default to box emoji if no match

        JLabel iconLabel = new JLabel(emoji);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 36));
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        iconLabel.setVerticalAlignment(SwingConstants.CENTER);
        iconLabel.setPreferredSize(new Dimension(60, 60));

        // Tooltip for the emoji
        iconLabel.setToolTipText("Product: " + name);

        // Rounded corners for the icon (JLabel)
        iconLabel.setOpaque(true);
        iconLabel.setBackground(new Color(240, 240, 240));
        iconLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2, true));

        card.add(iconLabel, BorderLayout.WEST);

        // Text panel with product details
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setOpaque(false); // transparent

        JLabel nameLabel = new JLabel("Name: " + name);
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));

        JLabel productIdLabel = new JLabel("Product ID: " + productId);
        productIdLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JLabel qtyLabel = new JLabel("Quantity: " + quantity);
        qtyLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JLabel priceLabel = new JLabel("Price: ₱" + price);
        priceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        textPanel.add(nameLabel);
        textPanel.add(productIdLabel);
        textPanel.add(qtyLabel);
        textPanel.add(priceLabel);

        card.add(textPanel, BorderLayout.CENTER);

        // Total label with pill-style badge
        JLabel totalLabel = new JLabel("₱" + itemTotal.setScale(2, RoundingMode.HALF_UP));
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        totalLabel.setForeground(new Color(34, 139, 34)); // Green color
        totalLabel.setOpaque(true);
        totalLabel.setBackground(new Color(232, 245, 233)); // light green background
        totalLabel.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        totalLabel.setHorizontalAlignment(SwingConstants.CENTER);
        totalLabel.setVerticalAlignment(SwingConstants.CENTER);

        JPanel totalPanel = new JPanel(new BorderLayout());
        totalPanel.setOpaque(false);
        totalPanel.add(totalLabel, BorderLayout.SOUTH);

        card.add(totalPanel, BorderLayout.EAST);

        // Hover effect for card
        card.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Change background color on hover
                card.setBackground(new Color(240, 240, 240)); // Light gray on hover
                card.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Reset background color when mouse leaves
                card.setBackground(Color.WHITE);
                card.setCursor(Cursor.getDefaultCursor());
            }
        });

    card.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        // Step 1: Prompt for Admin Code
        String adminCode = "0123"; // Set your own secure admin code
        String enteredCode = JOptionPane.showInputDialog(null, "Enter Admin Code to Void Transaction:", "Authorization Required", JOptionPane.WARNING_MESSAGE);

        // Step 2: Check if the entered code matches the correct admin code
        if (adminCode.equals(enteredCode)) {
            // Step 3: Confirm Removal
            int confirm = JOptionPane.showConfirmDialog(card,
                "Do you want to remove this item from the cart?",
                "Remove Product", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                // 1. Return quantity back to the database
                try {
                    Connection conn = DatabaseConnection.getConnection(); // Get the connection

                    String updateQuery = "UPDATE products SET stocks = stocks + ? WHERE product_id = ?";
                    PreparedStatement pst = conn.prepareStatement(updateQuery);
                    pst.setInt(1, quantity); // quantity to return
                    pst.setString(2, productId); // product ID
                    int rowsAffected = pst.executeUpdate(); // Execute update query
                    System.out.println("Rows affected in database: " + rowsAffected); // Debugging message

                    // 2. Check if the update was successful and update the UI table (productsTable)
                    if (rowsAffected > 0) {
                        for (int i = 0; i < productsTable.getRowCount(); i++) {
                            String tableProductId = productsTable.getValueAt(i, 0).toString();
                            if (tableProductId.equals(productId)) {
                                int currentStock = Integer.parseInt(productsTable.getValueAt(i, 2).toString());
                                int updatedStock = currentStock + quantity;
                                productsTable.setValueAt(updatedStock, i, 2); // Update stock in the table
                                break;
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(card, "Product ID not found in the database.", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    pst.close(); // Close PreparedStatement

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(card, "Failed to update stock in the database.", "Error", JOptionPane.ERROR_MESSAGE);
                }

                // 3. Subtract from total
                totalPrice = totalPrice.subtract(itemTotal);
                updateTotalTextField();

                // 4. Remove the card visually from the cart
                productPanel.remove(card);
                productPanel.revalidate();
                productPanel.repaint();
            }
        } else {
            JOptionPane.showMessageDialog(card, "Incorrect admin code. You are not authorized to remove this item.", "Authorization Failed", JOptionPane.ERROR_MESSAGE);
        }
    }
});

        // Add card to product panel
        productPanel.add(card);
        productPanel.add(Box.createRigidArea(new Dimension(0, 10))); // spacing between cards
        productPanel.revalidate();
        productPanel.repaint();

        // Update the total in the JTextField after adding the item
        updateTotalTextField();
    }

    // Private method to update the total in the JTextField
    private void updateTotalTextField() {
        totalTxt.setText("" + totalPrice.setScale(2, RoundingMode.HALF_UP));
    }

    

    private void computeChange() {
        try {
            // Ensure the text fields are not empty
            if (totalTxt.getText().trim().isEmpty() || paymentTextField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid amount.", "Input Error", JOptionPane.WARNING_MESSAGE);
                changeTextField.setText(""); // Clear change field
                return;
            }

            // Clean inputs (remove ₱ symbol or other non-numeric characters)
            String totalText = totalTxt.getText().replaceAll("[^0-9.]", "").trim();
            String paymentText = paymentTextField.getText().replaceAll("[^0-9.]", "").trim();

            double totalCost = Double.parseDouble(totalText);
            double amountPaid = Double.parseDouble(paymentText);

            if (amountPaid < totalCost) {
                JOptionPane.showMessageDialog(null, "❌ Insufficient Payment! Please enter a sufficient amount.",
                        "Payment Error", JOptionPane.ERROR_MESSAGE);
                changeTextField.setText(""); // Clear the change field
                return;
            }

            // Compute change
            double change = amountPaid - totalCost;
            changeTextField.setText(String.format("%.2f", change));

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "❗ Invalid input! Please enter a valid number.",
                    "Input Error", JOptionPane.WARNING_MESSAGE);
            changeTextField.setText(""); // Clear the change field
        }
    }

    private JPanel productPanel;  // Make sure this is initialized properly elsewhere in the class.
private void voidAllItems() {
    String adminCode = "0123";
    String enteredCode = JOptionPane.showInputDialog(
            null, "Enter Admin Code to Void All Items:", "Authorization Required", JOptionPane.WARNING_MESSAGE);

    if (enteredCode != null && adminCode.equals(enteredCode)) {
        int confirm = JOptionPane.showConfirmDialog(
                null, "Do you want to remove all items from the cart?", "Remove All Products", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            for (int i = 0; i < productsPanel.getComponentCount(); i++) {
                Component comp = productsPanel.getComponent(i);

                if (comp instanceof JPanel card) {
                    String productId = card.getName();
                    int quantity = getQuantityFromCard(card);

                    try (Connection conn = DatabaseConnection.getConnection();
                         PreparedStatement pst = conn.prepareStatement(
                                 "UPDATE products SET stocks = stocks + ? WHERE product_id = ?")) {

                        pst.setInt(1, quantity);
                        pst.setString(2, productId);
                        int rowsAffected = pst.executeUpdate();

                        if (rowsAffected > 0) {
                            updateStockInTable(productId, quantity);
                        } else {
                            JOptionPane.showMessageDialog(null,
                                    "Product ID " + productId + " not found in the database.",
                                    "Error", JOptionPane.ERROR_MESSAGE);
                        }

                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null,
                                "Failed to update stock for " + productId + ".", "Database Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }

            totalPrice = totalPrice.subtract(getTotalFromCart());
            updateTotalTextField();

            productsPanel.removeAll();
            productsPanel.revalidate();
            productsPanel.repaint();
        }
    } else if (enteredCode != null) {
        JOptionPane.showMessageDialog(null,
                "Incorrect admin code. You are not authorized to remove all items.",
                "Authorization Failed", JOptionPane.ERROR_MESSAGE);
    }
}
private BigDecimal getTotalFromCart() {
    BigDecimal total = BigDecimal.ZERO;

    for (int i = 0; i < productsPanel.getComponentCount(); i++) {
        JPanel card = (JPanel) productsPanel.getComponent(i);
        total = total.add(getItemTotalFromCard(card));
    }

    return total;
}

private BigDecimal getItemTotalFromCard(JPanel card) {
    JPanel totalPanel = (JPanel) card.getComponent(2); // East panel
    JLabel totalLabel = (JLabel) totalPanel.getComponent(0); // Label like "₱100.00"
    String totalText = totalLabel.getText().replace("₱", "").trim();
    return new BigDecimal(totalText);
}



private void updateStockInTable(String productId, int quantity) {
    for (int j = 0; j < productsTable.getRowCount(); j++) {
        String tableProductId = productsTable.getValueAt(j, 0).toString();
        if (productId.equals(tableProductId)) {
            int currentStock = Integer.parseInt(productsTable.getValueAt(j, 2).toString());
            productsTable.setValueAt(currentStock + quantity, j, 2);
            break;
        }
    }
}
private int getQuantityFromCard(JPanel card) {
    for (Component comp : card.getComponents()) {
        if (comp instanceof JPanel) {
            JPanel innerPanel = (JPanel) comp;
            for (Component innerComp : innerPanel.getComponents()) {
                if (innerComp instanceof JLabel) {
                    JLabel label = (JLabel) innerComp;
                    String text = label.getText();
                    if (text.startsWith("Qty:")) {
                        try {
                            return Integer.parseInt(text.split(":")[1].trim());
                        } catch (NumberFormatException e) {
                            System.err.println("Invalid quantity format: " + text);
                        }
                    }
                }
            }
        }
    }
    return 0; // Default if not found
}


    private void applyRightShadow(JPanel panel) {
        panel.setBorder(BorderFactory.createMatteBorder(
                0, 0, 0, 5, new Color(0, 0, 0, 30)
        ));
    }
    private void populateServiceTable() {
    DefaultTableModel model = (DefaultTableModel) serviceTable.getModel();
    model.setRowCount(0); // Clear table first

    String query = "SELECT service_id, service_name, charge, service_type FROM services";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("service_id"),
                rs.getString("service_name"),
                rs.getBigDecimal("charge"),
                rs.getString("service_type")
            });
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error loading services: " + e.getMessage());
    }
}

private void populateReservationsUsingProcedure() {
    DefaultTableModel model = (DefaultTableModel) reservationsTable.getModel();
    model.setRowCount(0);

    try (Connection conn = DatabaseConnection.getConnection();
         CallableStatement stmt = conn.prepareCall("{CALL GetUpcomingBookedReservations()}");
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("reservation_id"),
                rs.getDate("reservation_date"),
                rs.getString("name"),
                rs.getString("contact"),
                rs.getString("service_name"),
                rs.getBoolean("home_service") ? "Yes" : "No",
                rs.getString("place"),


            });
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error fetching reservations: " + e.getMessage());
    }
}


public void addServiceCard(JPanel servicePanel, String serviceId, String name, int quantity, BigDecimal price) {
    BigDecimal itemTotal = price.multiply(new BigDecimal(quantity));
    totalPrice = totalPrice.add(itemTotal);

    // Create the card panel
    JPanel card = new JPanel(new BorderLayout(10, 0));
    card.setBackground(Color.WHITE);
    card.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
    card.setPreferredSize(new Dimension(360, 120));
    card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));

    // Emoji icon for services
    String emoji = name.toLowerCase().contains("consult") ? "📞"
                : name.toLowerCase().contains("groom") ? "✂️"
                : name.toLowerCase().contains("check") ? "🩺"
                : "🛠️";

    JLabel iconLabel = new JLabel(emoji);
    iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 36));
    iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
    iconLabel.setVerticalAlignment(SwingConstants.CENTER);
    iconLabel.setPreferredSize(new Dimension(60, 60));
    iconLabel.setOpaque(true);
    iconLabel.setBackground(new Color(240, 240, 240));
    iconLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2, true));
    iconLabel.setToolTipText("Service: " + name);
    card.add(iconLabel, BorderLayout.WEST);

    // Panel for service details
    JPanel textPanel = new JPanel();
    textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
    textPanel.setOpaque(false);

    JLabel nameLabel = new JLabel("Service: " + name);
    nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));

    JLabel serviceIdLabel = new JLabel("Service ID: " + serviceId);
    serviceIdLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));

    JLabel qtyLabel = new JLabel("Quantity: " + quantity);
    qtyLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));

    JLabel priceLabel = new JLabel("Price per unit: ₱" + price);
    priceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));

    textPanel.add(nameLabel);
    textPanel.add(serviceIdLabel);
    textPanel.add(qtyLabel);
    textPanel.add(priceLabel);
    card.add(textPanel, BorderLayout.CENTER);

    // Total cost label
    JLabel totalLabel = new JLabel("₱" + itemTotal.setScale(2, RoundingMode.HALF_UP));
    totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
    totalLabel.setForeground(new Color(34, 139, 34));
    totalLabel.setOpaque(true);
    totalLabel.setBackground(new Color(232, 245, 233));
    totalLabel.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
    totalLabel.setHorizontalAlignment(SwingConstants.CENTER);

    JPanel totalPanel = new JPanel(new BorderLayout());
    totalPanel.setOpaque(false);
    totalPanel.add(totalLabel, BorderLayout.SOUTH);
    card.add(totalPanel, BorderLayout.EAST);

    // Hover effect
    card.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseEntered(MouseEvent e) {
            card.setBackground(new Color(240, 240, 240));
            card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        @Override
        public void mouseExited(MouseEvent e) {
            card.setBackground(Color.WHITE);
            card.setCursor(Cursor.getDefaultCursor());
        }

        @Override
        public void mouseClicked(MouseEvent e) {
            String adminCode = "0123";
            String enteredCode = JOptionPane.showInputDialog(null, "Enter Admin Code to Void Service:", "Authorization Required", JOptionPane.WARNING_MESSAGE);

            if (adminCode.equals(enteredCode)) {
                int confirm = JOptionPane.showConfirmDialog(card, "Do you want to remove this service?", "Remove Service", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    totalPrice = totalPrice.subtract(itemTotal);
                    updateTotalTextField();

                    servicePanel.remove(card);
                    servicePanel.revalidate();
                    servicePanel.repaint();
                }
            } else {
                JOptionPane.showMessageDialog(card, "Incorrect admin code. You are not authorized to remove this item.", "Authorization Failed", JOptionPane.ERROR_MESSAGE);
            }
        }
    });

    // Add card to the service panel
    servicePanel.add(card);
    servicePanel.add(Box.createRigidArea(new Dimension(0, 10))); // Space between cards

    // Revalidate and repaint the service panel to update the UI
    servicePanel.revalidate();
    servicePanel.repaint();

    updateTotalField();
}
private void updateTotalField() {
    totalLabelField.setText( totalPrice.setScale(2, RoundingMode.HALF_UP).toPlainString());
}
private void computeChangeReservation() {
    try {
        // Ensure the text fields are not empty
        if (totalLabelField.getText().trim().isEmpty() || paymentTextField1.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter a valid amount.", "Input Error", JOptionPane.WARNING_MESSAGE);
            changeTextField1.setText(""); // Clear change field
            return;
        }

        // Clean inputs (remove ₱ symbol or other non-numeric characters)
        String totalText = totalLabelField.getText().replaceAll("[^0-9.]", "").trim();
        String paymentText = paymentTextField1.getText().replaceAll("[^0-9.]", "").trim();

        double totalCost = Double.parseDouble(totalText);
        double amountPaid = Double.parseDouble(paymentText);

        if (amountPaid < totalCost) {
            JOptionPane.showMessageDialog(null, "❌ Insufficient Payment! Please enter a sufficient amount.",
                    "Payment Error", JOptionPane.ERROR_MESSAGE);
            changeTextField1.setText(""); // Clear the change field
            return;
        }

        // Compute change
        double change = amountPaid - totalCost;
        changeTextField1.setText(String.format("%.2f", change));

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "❗ Invalid input! Please enter a valid number.",
                "Input Error", JOptionPane.WARNING_MESSAGE);
        changeTextField1.setText(""); // Clear the change field
    }
}

private void showCustomerSelectionDialog() {
    JDialog dialog = new JDialog((Frame) null, "Select Customer Type", true);
    dialog.setLayout(new BorderLayout(15, 15));
    dialog.setSize(450, 300);
    dialog.setLocationRelativeTo(null);
    dialog.getContentPane().setBackground(Color.WHITE);

    // Fonts for a modern feel
    Font titleFont = new Font("Segoe UI", Font.BOLD, 16);
    Font labelFont = new Font("Segoe UI", Font.PLAIN, 14);
    Font fieldFont = new Font("Segoe UI", Font.PLAIN, 14);

    // Top Panel: Customer Type Buttons
    JPanel selectionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
    selectionPanel.setBackground(Color.WHITE);
    JButton walkInButton = new JButton("Walk-in");
    JButton reservationButton = new JButton("Reservation");

    // Button Styling: Rounded corners, flat colors, no borders
    for (JButton button : new JButton[]{walkInButton, reservationButton}) {
        button.setFocusPainted(false);
        button.setBackground(new Color(66, 133, 244));  // Blue
        button.setForeground(Color.WHITE);
        button.setFont(labelFont);
        button.setBorder(BorderFactory.createLineBorder(new Color(66, 133, 244), 2, true));
        button.setPreferredSize(new Dimension(120, 40));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    selectionPanel.add(walkInButton);
    selectionPanel.add(reservationButton);
    dialog.add(selectionPanel, BorderLayout.NORTH);

    // Center Panel: Dynamic Form
    JPanel dynamicPanel = new JPanel(new CardLayout(10, 10));
    dynamicPanel.setBackground(Color.WHITE);
    dynamicPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

    // Walk-in Form
    JPanel walkInPanel = new JPanel(new GridLayout(2, 1, 10, 10));
    walkInPanel.setBackground(Color.WHITE);
    JLabel walkInLabel = new JLabel("Customer Name:");
    walkInLabel.setFont(labelFont);
    JTextField walkInNameField = new JTextField();
    walkInNameField.setFont(fieldFont);
    walkInNameField.setBorder(BorderFactory.createLineBorder(new Color(204, 204, 204)));
    walkInPanel.add(walkInLabel);
    walkInPanel.add(walkInNameField);

    // Reservation Form
    JPanel reservationPanel = new JPanel(new GridLayout(3, 1, 10, 10));
    reservationPanel.setBackground(Color.WHITE);
    JLabel reservationLabel = new JLabel("Select Reservation:");
    reservationLabel.setFont(labelFont);
    JComboBox<String> reservationComboBox = new JComboBox<>();
    reservationComboBox.setFont(fieldFont);
    reservationComboBox.setBorder(BorderFactory.createLineBorder(new Color(204, 204, 204)));
    JTextField reservationDateField = new JTextField();
    reservationDateField.setFont(fieldFont);
    reservationDateField.setEditable(false);
    reservationDateField.setBackground(new Color(240, 240, 240));
    reservationDateField.setBorder(BorderFactory.createLineBorder(new Color(204, 204, 204)));
    reservationPanel.add(reservationLabel);
    reservationPanel.add(reservationComboBox);
    reservationPanel.add(reservationDateField);

    dynamicPanel.add(walkInPanel, "WALKIN");
    dynamicPanel.add(reservationPanel, "RESERVE");
    dialog.add(dynamicPanel, BorderLayout.CENTER);

    // Populate ComboBox
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement("SELECT reservation_id, name, reservation_date FROM services_reservations WHERE status = 'Booked'")) {
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int id = rs.getInt("reservation_id");
            String name = rs.getString("name");
            reservationComboBox.addItem(id + " - " + name);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    // Update reservation date when selecting
    reservationComboBox.addActionListener(e -> {
        String selected = (String) reservationComboBox.getSelectedItem();
        if (selected != null && selected.contains(" - ")) {
            try {
                int reservationId = Integer.parseInt(selected.split(" - ")[0]);
                try (Connection conn = DatabaseConnection.getConnection();
                     PreparedStatement ps = conn.prepareStatement("SELECT reservation_date FROM services_reservations WHERE reservation_id = ?")) {
                    ps.setInt(1, reservationId);
                    ResultSet rs = ps.executeQuery();
                    if (rs.next()) {
                        reservationDateField.setText(String.valueOf(rs.getDate("reservation_date")));
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    });

    // Bottom Panel: Proceed Button
    JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    bottomPanel.setBackground(Color.WHITE);
    JButton proceedButton = new JButton("Proceed");
    proceedButton.setFont(labelFont);
    proceedButton.setBackground(new Color(15, 157, 88));  // Green
    proceedButton.setForeground(Color.WHITE);
    proceedButton.setFocusPainted(false);
    proceedButton.setBorder(BorderFactory.createLineBorder(new Color(15, 157, 88), 2, true));
    proceedButton.setPreferredSize(new Dimension(120, 40));
    bottomPanel.add(proceedButton);
    dialog.add(bottomPanel, BorderLayout.SOUTH);

    // Button Actions
    walkInButton.addActionListener(e -> {
        CardLayout cl = (CardLayout) dynamicPanel.getLayout();
        cl.show(dynamicPanel, "WALKIN");
    });

    reservationButton.addActionListener(e -> {
        CardLayout cl = (CardLayout) dynamicPanel.getLayout();
        cl.show(dynamicPanel, "RESERVE");
    });

    proceedButton.addActionListener(e -> {
        // Handle Walk-in
        if (walkInNameField.isShowing()) {
            String name = walkInNameField.getText().trim();
            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Please enter a customer name.");
                return;
            }
            dialog.dispose();
            processServicePayment(name, new java.sql.Date(System.currentTimeMillis()), "Walk-in");
        } 
        // Handle Reservation
        else if (reservationComboBox.isShowing()) {
            String selected = (String) reservationComboBox.getSelectedItem();
            if (selected == null) {
                JOptionPane.showMessageDialog(dialog, "Please select a reservation.");
                return;
            }
            String[] parts = selected.split(" - ");
            int reservationId = Integer.parseInt(parts[0]);
            String name = parts[1];
            Date date = Date.valueOf(reservationDateField.getText());
            dialog.dispose();
            processServicePayment(name, date, "Reservation (ID: " + reservationId + ")");
        } 
        // No customer type selected
        else {
            JOptionPane.showMessageDialog(dialog, "Please select a customer type.");
        }
    });

    dialog.setVisible(true);
}

private void processServicePayment(String customerName, Date reservationDate, String status) {
    try (Connection conn = DatabaseConnection.getConnection()) {
        conn.setAutoCommit(false);  // Disable auto-commit for transaction management

        // Step 1: Collect selected services
        List<JPanel> serviceCards = new ArrayList<>();
        for (Component comp : servicePanel.getComponents()) {
            if (comp instanceof JPanel) {
                serviceCards.add((JPanel) comp);
            }
        }

        // Validate that at least one service is selected
        if (serviceCards.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please select at least one service.");
            return;
        }

        // Calculate total amount based on selected services
        BigDecimal totalAmount = BigDecimal.ZERO;
        for (JPanel card : serviceCards) {
            JPanel centerPanel = (JPanel) card.getComponent(1);
            Component[] labels = centerPanel.getComponents();

            // Extract quantity and price from labels
            int qty = Integer.parseInt(((JLabel) labels[2]).getText().replace("Qty: ", "").trim());
            BigDecimal price = new BigDecimal(((JLabel) labels[3]).getText().replace("Price: ₱", "").trim());
            totalAmount = totalAmount.add(price.multiply(BigDecimal.valueOf(qty)));
        }

        // Step 2: Get payment input from the user
        String input = JOptionPane.showInputDialog(null, "Enter Amount Paid:");
        BigDecimal amountPaid;
        try {
            amountPaid = new BigDecimal(input.trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid payment amount.");
            return;
        }

        BigDecimal changeDue = amountPaid.subtract(totalAmount);

        // Step 3: Insert the sale record into `service_sales_items`
        String insertItemSQL = "INSERT INTO service_sales_items (customer_name, total_amount, amount_paid, change_due, reservation_date, service_date, status) VALUES (?, ?, ?, ?, ?, NOW(), ?)";
        try (PreparedStatement itemStmt = conn.prepareStatement(insertItemSQL, Statement.RETURN_GENERATED_KEYS)) {
            itemStmt.setString(1, customerName);
            itemStmt.setBigDecimal(2, totalAmount);
            itemStmt.setBigDecimal(3, amountPaid);
            itemStmt.setBigDecimal(4, changeDue);
            itemStmt.setDate(5, reservationDate);
            itemStmt.setString(6, "Paid");

            itemStmt.executeUpdate();
            ResultSet rs = itemStmt.getGeneratedKeys();

            // Retrieve the generated saleItemId
            int saleItemId = -1;
            if (rs.next()) {
                saleItemId = rs.getInt(1);
            } else {
                conn.rollback();
                JOptionPane.showMessageDialog(null, "Failed to save sale record.");
                return;
            }

            // Step 4: Insert each service into `service_sales`
            String insertServiceSQL = "INSERT INTO service_sales (service_sale_id, service_id, service_name, price) VALUES (?, ?, ?, ?)";
            try (PreparedStatement serviceStmt = conn.prepareStatement(insertServiceSQL)) {
                for (JPanel card : serviceCards) {
                    JPanel centerPanel = (JPanel) card.getComponent(1);
                    Component[] labels = centerPanel.getComponents();

                    // Extract service details
                    int serviceId = Integer.parseInt(((JLabel) labels[1]).getText().replace("Service ID: ", "").trim());
                    String serviceName = ((JLabel) labels[0]).getText().replace("Service: ", "").trim();
                    BigDecimal price = new BigDecimal(((JLabel) labels[3]).getText().replace("Price: ₱", "").trim());

                    // Set values for the batch insert
                    serviceStmt.setInt(1, saleItemId);
                    serviceStmt.setInt(2, serviceId);
                    serviceStmt.setString(3, serviceName);
                    serviceStmt.setBigDecimal(4, price);

                    serviceStmt.addBatch();
                }

                // Execute the batch insert
                serviceStmt.executeBatch();
                conn.commit();  // Commit the transaction

                JOptionPane.showMessageDialog(null, "Payment Successful!");
                // Optional: generate receipt
                // new ReceiptGenerator().generateServiceReceipt(saleItemId);
            }
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        try {
            conn.rollback();  // Rollback in case of an error
        } catch (SQLException e) {
            e.printStackTrace();
        }
        JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
    }
}


    public static void main(String args[]) {

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

                try {
                    UIManager.setLookAndFeel(new FlatLightLaf()); // Or FlatIntelliJLaf, FlatDarkLaf
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                // Launch your frame
                SwingUtilities.invokeLater(() -> {
                    new PointOfSale().setVisible(true);
                });
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel SidebarMenu;
    private javax.swing.JTextField changeTextField;
    private javax.swing.JTextField changeTextField1;
    private javax.swing.JPanel header;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JLabel nameTxt3;
    private javax.swing.JLabel nameTxt4;
    private javax.swing.JLabel nameTxt6;
    private javax.swing.JLabel nameTxt7;
    private javax.swing.JButton paybutton1;
    private javax.swing.JButton paybutton2;
    private javax.swing.JButton paybutton3;
    private javax.swing.JButton paybutton4;
    private javax.swing.JButton paybutton5;
    private javax.swing.JPanel paymentPanel;
    private javax.swing.JPanel paymentPanel1;
    private javax.swing.JTextField paymentTextField;
    private javax.swing.JTextField paymentTextField1;
    private javax.swing.JPanel productsPanel;
    private javax.swing.JTable productsTable;
    private javax.swing.JTable reservationsTable;
    private javax.swing.JScrollPane scrollPane;
    private javax.swing.JPanel servicePanel;
    private javax.swing.JTable serviceTable;
    private javax.swing.JTextField totalLabelField;
    private javax.swing.JTextField totalTxt;
    private javax.swing.JButton voidall;
    // End of variables declaration//GEN-END:variables

    private void applyShadow(JPanel jPanel1, int i, int i0, int i1, int i2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
