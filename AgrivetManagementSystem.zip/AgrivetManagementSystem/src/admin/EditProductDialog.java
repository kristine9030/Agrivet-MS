
package admin;

import admin.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

public class EditProductDialog extends JDialog {
    private JTextField nameField, categoryField, basePriceField, sellingPriceField, stocksField, supplierField;
    private JButton saveButton, cancelButton;
    private String productId;  // Product ID that we are editing
    private boolean updated = false;  // Flag to check if the product was updated

    // Constructor to initialize the dialog with existing product details
    public EditProductDialog(Frame parent, String productId, String name, String category,
                             double basePrice, double sellingPrice, int stocks, String supplier) {
        super(parent, "Edit Product", true);

        this.productId = productId;

        // Initialize the text fields with the existing product details
        nameField = new JTextField(name, 20);
        categoryField = new JTextField(category, 20);
        basePriceField = new JTextField(String.valueOf(basePrice), 20);
        sellingPriceField = new JTextField(String.valueOf(sellingPrice), 20);
        stocksField = new JTextField(String.valueOf(stocks), 20);
        supplierField = new JTextField(supplier, 20);

        // Buttons
        saveButton = new JButton("Save");
        cancelButton = new JButton("Cancel");

        // Layout setup
        setLayout(new GridLayout(7, 2, 10, 10));

        // Add labels and text fields
        add(new JLabel("Product Name:"));
        add(nameField);
        add(new JLabel("Category:"));
        add(categoryField);
        add(new JLabel("Base Price:"));
        add(basePriceField);
        add(new JLabel("Selling Price:"));
        add(sellingPriceField);
        add(new JLabel("Stocks:"));
        add(stocksField);
        add(new JLabel("Supplier:"));
        add(supplierField);

        // Add buttons at the bottom
        add(saveButton);
        add(cancelButton);

        // Action Listeners for buttons
        saveButton.addActionListener(e -> saveProduct());
        cancelButton.addActionListener(e -> cancelEdit());

        // Set dialog properties
        setSize(400, 300);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    // Method to save the edited product details
    private void saveProduct() {
        // Get the updated values from the text fields
        String name = nameField.getText();
        String category = categoryField.getText();
        double basePrice = Double.parseDouble(basePriceField.getText());
        double sellingPrice = Double.parseDouble(sellingPriceField.getText());
        int stocks = Integer.parseInt(stocksField.getText());
        String supplier = supplierField.getText();

        // SQL update query
        String sql = "UPDATE product_inventory SET name = ?, category = ?, base_price = ?, selling_price = ?, stocks = ?, supplier = ? WHERE product_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            // Set the updated values into the prepared statement
            pst.setString(1, name);
            pst.setString(2, category);
            pst.setDouble(3, basePrice);
            pst.setDouble(4, sellingPrice);
            pst.setInt(5, stocks);
            pst.setString(6, supplier);
            pst.setString(7, productId);  // Set the product ID that is being updated

            int result = pst.executeUpdate();

            if (result > 0) {
                updated = true;  // Mark as updated
                JOptionPane.showMessageDialog(this, "Product updated successfully!");
                dispose();  // Close the dialog
            } else {
                JOptionPane.showMessageDialog(this, "❌ Error: Could not update the product.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "❌ Failed to update product:\n" + e.getMessage());
        }
    }

    // Method to cancel the editing (close the dialog without saving)
    private void cancelEdit() {
        dispose();  // Close the dialog without saving
    }

    // Getter methods to retrieve the updated product details
    public boolean isUpdated() {
        return updated;
    }

    public String getProductName() {
        return nameField.getText();
    }

    public String getCategory() {
        return categoryField.getText();
    }

    public double getBasePrice() {
        return Double.parseDouble(basePriceField.getText());
    }

    public double getSellingPrice() {
        return Double.parseDouble(sellingPriceField.getText());
    }

    public int getStocks() {
        return Integer.parseInt(stocksField.getText());
    }

    public String getSupplier() {
        return supplierField.getText();
    }
}

