
package admin;

public class UserSession {
    private static UserSession instance;

    private int userId;
    private String username;
    private String role;
    private String assignedDorm;

    private UserSession(int userId, String username, String role, String assignedDorm) {
        this.userId = userId;
        this.username = username;
        this.role = role;
        this.assignedDorm = assignedDorm;
    }

    public static void create(int userId, String username, String role, String assignedDorm) {
        instance = new UserSession(userId, username, role, assignedDorm);
    }

    public static UserSession getInstance() {
        return instance;
    }

    public static void clear() {
        instance = null;
    }

    public int getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getRole() {
        return role;
    }

    public String getAssignedDorm() {
        return assignedDorm;
    }
}
