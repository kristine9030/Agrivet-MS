
package admin;

import com.formdev.flatlaf.FlatLightLaf;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;

public class AgrivetReservationUI extends JFrame {

    private JPanel calendarPanel;
    private JPanel reservationPanel;
    private JLabel selectedDateLabel;
    private LocalDate selectedDate = LocalDate.now();
    private final Map<LocalDate, java.util.List<String>> reservations = new HashMap<>();

    public AgrivetReservationUI() {
        FlatLightLaf.setup(); // Enable FlatLaf
        setTitle("AgriVet Reservation System");
        setSize(900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        selectedDateLabel = new JLabel();
        selectedDateLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        selectedDateLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        calendarPanel = new JPanel(new GridLayout(0, 7));
        calendarPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        reservationPanel = new JPanel();
        reservationPanel.setLayout(new BoxLayout(reservationPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(reservationPanel);

        JButton newButton = new JButton("New Reservation");
        newButton.addActionListener(e -> addMockReservation());

        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(selectedDateLabel, BorderLayout.NORTH);
        rightPanel.add(scrollPane, BorderLayout.CENTER);
        rightPanel.add(newButton, BorderLayout.SOUTH);

        add(calendarPanel, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.EAST);

        renderCalendar(LocalDate.now());
        updateReservationList();
    }

    private void renderCalendar(LocalDate date) {
        calendarPanel.removeAll();
        YearMonth ym = YearMonth.of(date.getYear(), date.getMonthValue());
        LocalDate firstOfMonth = ym.atDay(1);
        int dayOfWeek = firstOfMonth.getDayOfWeek().getValue(); // 1 = Monday ... 7 = Sunday

        int startOffset = dayOfWeek % 7;

        for (int i = 0; i < startOffset; i++) {
            calendarPanel.add(new JLabel(""));
        }

        for (int day = 1; day <= ym.lengthOfMonth(); day++) {
            LocalDate dayDate = ym.atDay(day);
            JButton dayBtn = new JButton(String.valueOf(day));
            if (reservations.containsKey(dayDate)) {
                dayBtn.setBackground(new Color(0xFFDEAD)); // Highlight with light brown
            }

            if (dayDate.equals(selectedDate)) {
                dayBtn.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
            }

            dayBtn.addActionListener(e -> {
                selectedDate = dayDate;
                renderCalendar(selectedDate); // Re-render to show selection
                updateReservationList();
            });

            calendarPanel.add(dayBtn);
        }

        calendarPanel.revalidate();
        calendarPanel.repaint();
    }

    private void updateReservationList() {
        reservationPanel.removeAll();
        selectedDateLabel.setText(selectedDate.toString());

        java.util.List<String> tasks = reservations.getOrDefault(selectedDate, new ArrayList<>());
        if (tasks.isEmpty()) {
            reservationPanel.add(new JLabel("No reservations."));
        } else {
            for (String task : tasks) {
                JLabel label = new JLabel("• " + task);
                label.setFont(new Font("SansSerif", Font.PLAIN, 14));
                label.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
                reservationPanel.add(label);
            }
        }

        reservationPanel.revalidate();
        reservationPanel.repaint();
    }

    private void addMockReservation() {
        String[] services = {"Deworming", "Vaccination", "Check-up", "Castration"};
        String task = (String) JOptionPane.showInputDialog(this,
                "Select service", "New Reservation",
                JOptionPane.PLAIN_MESSAGE, null, services, services[0]);

        if (task != null) {
            reservations.computeIfAbsent(selectedDate, k -> new ArrayList<>()).add(task);
            renderCalendar(selectedDate);
            updateReservationList();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AgrivetReservationUI().setVisible(true));
    }
}
