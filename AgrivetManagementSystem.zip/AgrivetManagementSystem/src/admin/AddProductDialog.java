package admin;

import com.formdev.flatlaf.FlatLightLaf;
import com.toedter.calendar.JDateChooser;
import admin.ManageProducts;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.DecimalFormat;
import java.util.Date;

public class AddProductDialog extends JDialog {

    private JTextField productIdField, nameField, basePriceField, profitRateField, profitCostField,
            sellingPriceField, stocksField, customCategoryField, customSupplierField;
    private JComboBox<String> categoryComboBox, supplierComboBox;
    private JDateChooser expirationDateChooser;
    private ManageProducts manageProductsRef; // To hold the reference of ManageProducts

    // Database connection setup
    private Connection con;
    private PreparedStatement ps;
    private ResultSet rs;

    public AddProductDialog(Frame parent, ManageProducts manageProducts) {
        super(parent, "Add New Product         ", true);
        this.manageProductsRef = manageProducts;

        FlatLightLaf.setup();
        UIManager.put("defaultFont", new Font("Poppins", Font.PLAIN, 12));

        setSize(500, 580);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(20, 30, 20, 30));
        panel.setBackground(Color.WHITE);

        JLabel titleLabel = new JLabel("Add New Product");
        titleLabel.setFont(new Font("Poppins", Font.BOLD, 16));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(titleLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Initialize fields
        productIdField = new JTextField();
        nameField = new JTextField();
        basePriceField = new JTextField();
        profitRateField = new JTextField();
        profitCostField = new JTextField();
        profitCostField.setEnabled(false);
        sellingPriceField = new JTextField();
        sellingPriceField.setEnabled(false);
        stocksField = new JTextField();

        categoryComboBox = new JComboBox<>();
        supplierComboBox = new JComboBox<>();

        customCategoryField = new JTextField();
        customCategoryField.setVisible(false); // Initially hidden
        customSupplierField = new JTextField();
        customSupplierField.setVisible(false); // Initially hidden

        expirationDateChooser = new JDateChooser();
        expirationDateChooser.setDateFormatString("yyyy-MM-dd");

        profitRateField.addKeyListener(new PriceCalculator());
        basePriceField.addKeyListener(new PriceCalculator());

        // Show the custom category field if "Other" is selected
        categoryComboBox.addActionListener(e -> {
            if ("Other".equals(categoryComboBox.getSelectedItem())) {
                customCategoryField.setVisible(true);
            } else {
                customCategoryField.setVisible(false);
            }
            pack(); // Resize dialog to fit new field
        });

        // Show the custom supplier field if "Other" is selected
        supplierComboBox.addActionListener(e -> {
            if ("Other".equals(supplierComboBox.getSelectedItem())) {
                customSupplierField.setVisible(true);
            } else {
                customSupplierField.setVisible(false);
            }
            pack(); // Resize dialog to fit new field
        });

        addField(panel, "Product ID", productIdField);
        addField(panel, "Product Name", nameField);
        addField(panel, "Base Price", basePriceField);
        addField(panel, "Profit Rate (%)", profitRateField);
        addField(panel, "Profit Amount", profitCostField);
        addField(panel, "Selling Price", sellingPriceField);
        addField(panel, "Stocks", stocksField);
        addField(panel, "Category", categoryComboBox);
        addField(panel, "Other Category", customCategoryField); // Add custom category input
        addField(panel, "Supplier", supplierComboBox);
        addField(panel, "Other Supplier", customSupplierField); // Add custom supplier input
        addField(panel, "Expiration Date", expirationDateChooser);

        JButton saveButton = new JButton("Save");
        styleButton(saveButton, new Color(0, 123, 255), Color.WHITE);
        saveButton.addActionListener(e -> {
            saveProduct();
            manageProductsRef.loadProductsTable(); // Refresh products table after saving
        });

        JButton cancelButton = new JButton("Cancel");
        styleButton(cancelButton, Color.LIGHT_GRAY, Color.BLACK);
        cancelButton.addActionListener(e -> dispose());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(15, 0, 0, 0));
        buttonPanel.add(cancelButton);
        buttonPanel.add(saveButton);

        add(panel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Load Categories and Suppliers from Database
        loadCategories();
        loadSuppliers();
    }

    private void loadCategories() {
        try {
            con = DatabaseConnection.getConnection();
            String sql = "SELECT category_name FROM categories";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            categoryComboBox.removeAllItems();
            categoryComboBox.addItem("Other"); // Add "Other" option for custom input

            while (rs.next()) {
                categoryComboBox.addItem(rs.getString("category_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadSuppliers() {
        try {
            con = DatabaseConnection.getConnection();
            String sql = "SELECT supplier_name FROM suppliers";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            supplierComboBox.removeAllItems();
            supplierComboBox.addItem("Other"); // Add "Other" option for custom input

            while (rs.next()) {
                supplierComboBox.addItem(rs.getString("supplier_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addField(JPanel panel, String labelText, JComponent inputField) {
        JPanel fieldPanel = new JPanel(new BorderLayout(5, 0));
        fieldPanel.setOpaque(false);

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Poppins", Font.PLAIN, 12));
        label.setPreferredSize(new Dimension(120, 28));
        label.setHorizontalAlignment(SwingConstants.LEFT);

        inputField.setPreferredSize(new Dimension(280, 28));

        fieldPanel.add(label, BorderLayout.WEST);
        fieldPanel.add(inputField, BorderLayout.CENTER);

        panel.add(fieldPanel);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
    }

    private void styleButton(JButton button, Color bg, Color fg) {
        button.setPreferredSize(new Dimension(100, 35));
        button.setBackground(bg);
        button.setForeground(fg);
        button.setFocusPainted(false);
        button.setFont(new Font("Poppins", Font.PLAIN, 12));
    }

 private void saveProduct() {
    try {
        // Retrieve category_id based on selected category
        String category = "Other".equals(categoryComboBox.getSelectedItem()) ? customCategoryField.getText().trim() : (String) categoryComboBox.getSelectedItem();
        int categoryId = getCategoryId(category);

        // Retrieve supplier_id based on selected supplier
        String supplier = "Other".equals(supplierComboBox.getSelectedItem()) ? customSupplierField.getText().trim() : (String) supplierComboBox.getSelectedItem();
        int supplierId = getSupplierId(supplier);

        // Insert new category or supplier if needed
        if ("Other".equals(categoryComboBox.getSelectedItem()) && !customCategoryField.getText().trim().isEmpty()) {
            insertNewCategory(customCategoryField.getText().trim());
            categoryId = getCategoryId(customCategoryField.getText().trim()); // Get the newly inserted category ID
        }
        if ("Other".equals(supplierComboBox.getSelectedItem()) && !customSupplierField.getText().trim().isEmpty()) {
            insertNewSupplier(customSupplierField.getText().trim());
            supplierId = getSupplierId(customSupplierField.getText().trim()); // Get the newly inserted supplier ID
        }

        // Insert product into products table
        String sql = "INSERT INTO products (product_id, name, category_id, base_price, profit, selling_price, stocks, profit_rate, profit_cost, expiration_date, supplier_id) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, productIdField.getText().trim());
        ps.setString(2, nameField.getText().trim());
        ps.setInt(3, categoryId);
        ps.setDouble(4, Double.parseDouble(basePriceField.getText()));
        ps.setDouble(5, Double.parseDouble(profitCostField.getText()));
        ps.setDouble(6, Double.parseDouble(sellingPriceField.getText()));
        ps.setInt(7, Integer.parseInt(stocksField.getText()));
        ps.setDouble(8, Double.parseDouble(profitRateField.getText()));
        ps.setDouble(9, Double.parseDouble(profitCostField.getText()));

        Date date = expirationDateChooser.getDate();
        ps.setDate(10, date != null ? new java.sql.Date(date.getTime()) : null);

        ps.setInt(11, supplierId);
        ps.executeUpdate();

        JOptionPane.showMessageDialog(this, "Product added successfully!");
          // Call the loadProductsTable() method of ProductManager class to refresh the product table
        ManageProducts productManager = new ManageProducts(); // Create an instance of ProductManager
        productManager.loadProductsTable();  // Refresh the table
        dispose();
        

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error adding product", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private int getCategoryId(String category) {
    try {
        String sql = "SELECT category_id FROM categories WHERE category_name = ?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, category);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return rs.getInt("category_id");
        } else {
            return -1; // Return -1 if the category does not exist
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return -1;
    }
}

private int getSupplierId(String supplier) {
    try {
        String sql = "SELECT supplier_id FROM suppliers WHERE supplier_name = ?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, supplier);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return rs.getInt("supplier_id");
        } else {
            return -1; // Return -1 if the supplier does not exist
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return -1;
    }
}

    private void insertNewCategory(String category) {
        try {
            String sql = "INSERT INTO categories (category_name) VALUES (?)";
            ps = con.prepareStatement(sql);
            ps.setString(1, category);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void insertNewSupplier(String supplier) {
        try {
            String sql = "INSERT INTO suppliers (supplier_name) VALUES (?)";
            ps = con.prepareStatement(sql);
            ps.setString(1, supplier);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Price calculator for profit
    private class PriceCalculator extends KeyAdapter {
        @Override
        public void keyReleased(KeyEvent e) {
            try {
                double basePrice = Double.parseDouble(basePriceField.getText());
                double profitRate = Double.parseDouble(profitRateField.getText());
                double profit = basePrice * (profitRate / 100);
                profitCostField.setText(new DecimalFormat("#.##").format(profit));

                double sellingPrice = basePrice + profit;
                sellingPriceField.setText(new DecimalFormat("#.##").format(sellingPrice));

            } catch (NumberFormatException ex) {
                profitCostField.setText("");
                sellingPriceField.setText("");
            }
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ManageProducts manageProducts = new ManageProducts();  // Assuming ManageProducts is your main frame
            new AddProductDialog(manageProducts, manageProducts).setVisible(true);
        });
    }
}
