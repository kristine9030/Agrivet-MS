
package admin;

import com.formdev.flatlaf.FlatLightLaf;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractCellEditor;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import java.sql.*;

/**
 *
 * @author Kristine
 */
public class ManageProducts extends javax.swing.JFrame {

    
     private final Map<Integer, Color> rowColors = new HashMap<>();
     public ManageProducts() {
         initComponents();
         
         applyRightShadow(header);
        
         loadProductsTable();
         populateServiceTable();
     
        
     }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        header = new javax.swing.JPanel();
        SidebarMenu = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ProductsTable = new javax.swing.JTable();
        add3 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        serviceTable = new javax.swing.JTable();
        jLabel13 = new javax.swing.JLabel();
        add4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(238, 239, 238));

        header.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout headerLayout = new javax.swing.GroupLayout(header);
        header.setLayout(headerLayout);
        headerLayout.setHorizontalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1190, Short.MAX_VALUE)
        );
        headerLayout.setVerticalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        SidebarMenu.setBackground(new java.awt.Color(0, 96, 50));

        jButton1.setBackground(new java.awt.Color(0, 96, 50));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home (6).png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 51, 0));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/box-open.png"))); // NOI18N
        jButton2.setBorder(null);

        jButton4.setBackground(new java.awt.Color(0, 96, 50));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/newspaper.png"))); // NOI18N
        jButton4.setBorder(null);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(0, 96, 50));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/point-of-sale-bill.png"))); // NOI18N
        jButton5.setBorder(null);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(0, 96, 50));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/inventory-alt.png"))); // NOI18N
        jButton6.setBorder(null);

        jButton7.setBackground(new java.awt.Color(0, 96, 50));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/calendar-day.png"))); // NOI18N
        jButton7.setBorder(null);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SidebarMenuLayout = new javax.swing.GroupLayout(SidebarMenu);
        SidebarMenu.setLayout(SidebarMenuLayout);
        SidebarMenuLayout.setHorizontalGroup(
            SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SidebarMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(SidebarMenuLayout.createSequentialGroup()
                        .addGroup(SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE)
                            .addComponent(jButton7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        SidebarMenuLayout.setVerticalGroup(
            SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SidebarMenuLayout.createSequentialGroup()
                .addContainerGap(198, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(137, 137, 137))
        );

        ProductsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        ProductsTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ProductsTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(ProductsTable);

        add3.setBackground(new java.awt.Color(0, 153, 51));
        add3.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        add3.setForeground(new java.awt.Color(255, 255, 255));
        add3.setText("Add Product");
        add3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1156, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(add3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(85, 85, 85))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(add3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 524, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Manage Products ", jPanel2);

        serviceTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(serviceTable);

        jLabel13.setBackground(new java.awt.Color(102, 102, 102));
        jLabel13.setFont(new java.awt.Font("Poppins", 0, 24)); // NOI18N
        jLabel13.setText("Services ");

        add4.setBackground(new java.awt.Color(0, 153, 51));
        add4.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        add4.setForeground(new java.awt.Color(255, 255, 255));
        add4.setText("Add Services ");
        add4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(672, 672, 672)
                        .addComponent(add4, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1136, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(add4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 538, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        jTabbedPane1.addTab("Manage Services", jPanel3);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(SidebarMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(header, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1168, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(SidebarMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(header, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 643, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
public void loadProductsTable() {
    DefaultTableModel model = new DefaultTableModel(null, new Object[]{
        "", "Product ID", "Name", "Category", "Base Price", "Profit", "Selling Price",
        "Stocks", "Stock Status", "Expiration", "Supplier", "Action"
    }) {
        @Override
        public Class<?> getColumnClass(int columnIndex) {
            return columnIndex == 0 ? Boolean.class : Object.class;
        }

        @Override
        public boolean isCellEditable(int row, int column) {
            return column == 0; // Only checkbox editable
        }
    };

    ProductsTable.setModel(model); // Apply the model to the table
    model.setRowCount(0); // Clear any previous rows
    rowColors.clear(); // Clear color settings

    String sql = "SELECT p.product_id, p.name, c.category_name, p.base_price, p.profit, p.selling_price, " +
                 "p.stocks, p.expiration_date, s.supplier_name " +
                 "FROM products p " +
                 "JOIN categories c ON p.category_id = c.category_id " +
                 "JOIN suppliers s ON p.supplier_id = s.supplier_id"; // Join to get category and supplier names

    try (Connection conn = DatabaseConnection.getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date today = new Date();

        while (rs.next()) {
            // Fetch data from DB
            String productId = rs.getString("product_id");
            String name = rs.getString("name");
            String category = rs.getString("category_name");
            double basePrice = rs.getDouble("base_price");
            double profit = rs.getDouble("profit");
            double sellingPrice = rs.getDouble("selling_price");
            int stocks = rs.getInt("stocks");
            Date expirationDate = rs.getDate("expiration_date");
            String supplier = rs.getString("supplier_name");

            // Format expiration date
            String expDisplay = (expirationDate != null) ? sdf.format(expirationDate) : "N/A";

            // Determine stock status
            String stockStatus = "";
            if (stocks <= 0) {
                stockStatus = "Out Of Stock";
            } else if (stocks < 20) {
                stockStatus = "Low Stock";
            } else {
                stockStatus = "In Stock";
            }

            // Determine row color based on expiration
            Color rowColor;
            if (expirationDate != null) {
                long daysLeft = (expirationDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24);
                if (daysLeft < 0) {
                    rowColor = new Color(255, 102, 102); // Expired
                } else if (daysLeft <= 5) {
                    rowColor = new Color(255, 204, 102); // Near expiry
                } else {
                    rowColor = Color.WHITE; // Normal
                }
            } else {
                rowColor = Color.WHITE;
            }

            // Add row to the model
            Object[] rowData = {
                false, productId, name, category, basePrice, profit, sellingPrice,
                stocks, stockStatus, expDisplay, supplier, "Action"
            };

            model.addRow(rowData);
            rowColors.put(model.getRowCount() - 1, rowColor); // Save row color
        }

        // Apply renderers
        ProductsTable.setDefaultRenderer(Object.class, new SleekRenderer());
        ProductsTable.getColumn("Action").setCellRenderer(new ActionCellRenderer());

        styleSleekHeaders(ProductsTable);
        ProductsTable.getColumn("Action").setCellRenderer(new ActionCellRenderer());
        ProductsTable.getColumn("Action").setCellEditor(new ActionCellEditor(ProductsTable));

        // Force refresh of the table to ensure it reloads
        ProductsTable.revalidate();
        ProductsTable.repaint();

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "❌ Failed to load products:\n" + e.getMessage());
    }
}


class SleekRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
        boolean isSelected, boolean hasFocus, int row, int column) {

        Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        // Row background
        Color baseColor = rowColors.getOrDefault(row, (row % 2 == 0) ? Color.WHITE : new Color(245, 245, 245));
        cell.setBackground(isSelected ? new Color(51, 153, 255) : baseColor);

        // Default foreground
        cell.setForeground(isSelected ? Color.WHITE : Color.BLACK);

        // Special color for stock status
        if (column == 8 && value instanceof String) {
            String status = (String) value;
            if ("Low Stock".equalsIgnoreCase(status)) {
                cell.setForeground(new Color(255, 165, 0)); // Orange
            } else if ("Out Of Stock".equalsIgnoreCase(status)) {
                cell.setForeground(Color.RED);
            }
        }

        cell.setFont(new Font("Poppins", Font.PLAIN, 10));
        setHorizontalAlignment(SwingConstants.CENTER);

        return cell;
    }
    
    
}
class ActionCellRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
        boolean isSelected, boolean hasFocus, int row, int column) {

        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        panel.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());

     JButton edit = new JButton(new ImageIcon(getClass().getResource("/icons/edit(1).png")));
JButton delete = new JButton(new ImageIcon(getClass().getResource("/icons/delete.png")));


        edit.setPreferredSize(new Dimension(18, 18));
        delete.setPreferredSize(new Dimension(18, 18));

        // Style the buttons
        edit.setBorderPainted(false);
        delete.setBorderPainted(false);
        edit.setContentAreaFilled(false);
        delete.setContentAreaFilled(false);
        edit.setFocusable(false);
        delete.setFocusable(false);

        panel.add(edit);
        panel.add(delete);
        return panel;
    }
}

class ActionCellEditor extends AbstractCellEditor implements TableCellEditor {
    private JPanel panel;
    private JButton editButton, deleteButton;
    private JTable table;

    public ActionCellEditor(JTable table) {
        this.table = table;

        panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        panel.setOpaque(true);

        editButton = new JButton(new ImageIcon(getClass().getResource("/icons/edit(1).png")));
        deleteButton = new JButton(new ImageIcon(getClass().getResource("/icons/delete.png")));

        // Style
        Dimension size = new Dimension(18, 18);
        for (JButton btn : new JButton[]{editButton, deleteButton}) {
            btn.setPreferredSize(size);
            btn.setBorderPainted(false);
            btn.setContentAreaFilled(false);
            btn.setFocusable(false);
        }

        // Edit Action
        editButton.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1) {
                String productId = table.getValueAt(row, 1).toString();
                JOptionPane.showMessageDialog(table, "✏️ Edit Product: " + productId);
                // TODO: Show your custom edit dialog here
            }
        });

        // Delete Action
        deleteButton.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1) {
                String productId = table.getValueAt(row, 1).toString();
                int confirm = JOptionPane.showConfirmDialog(table,
                        "Are you sure you want to delete product ID: " + productId + "?",
                        "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    // TODO: Delete from database
                    ((DefaultTableModel) table.getModel()).removeRow(row);
                    JOptionPane.showMessageDialog(table, "🗑️ Product deleted.");
                }
            }
        });

        panel.add(editButton);
        panel.add(deleteButton);
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value,
            boolean isSelected, int row, int column) {
        return panel;
    }

    @Override
    public Object getCellEditorValue() {
        return null;
    }
}

private void styleSleekHeaders(JTable table) {
    JTableHeader header = table.getTableHeader();
    header.setDefaultRenderer(new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
            boolean isSelected, boolean hasFocus, int row, int column) {

            JLabel headerLabel = new JLabel(value.toString());
            headerLabel.setOpaque(true);
            headerLabel.setBackground(new Color(51, 51, 51));
            headerLabel.setForeground(Color.WHITE);
            headerLabel.setFont(new Font("Poppins", Font.BOLD, 12));
            headerLabel.setHorizontalAlignment(SwingConstants.CENTER);
            return headerLabel;
        }
    });

    table.setRowHeight(26);
    table.setShowGrid(false);
}


    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void add3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add3ActionPerformed
                           
    // Create a parent JFrame (you can replace this with your actual parent frame)
    JFrame parentFrame = (JFrame) SwingUtilities.getWindowAncestor((Component) evt.getSource());

    // Create an instance of ManageProducts (you can replace this with the actual reference you have)
    ManageProducts manageProductsRef = new ManageProducts();

    // Create an instance of AddProductDialog and pass the parent frame and manageProducts reference
    AddProductDialog addProductDialog = new AddProductDialog(parentFrame, manageProductsRef);

    // Make the dialog visible
    addProductDialog.setVisible(true);

    }//GEN-LAST:event_add3ActionPerformed

    private void ProductsTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ProductsTableMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ProductsTableMouseClicked

    private void add4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add4ActionPerformed
                              
    // Create a parent JFrame (you can replace this with your actual parent frame)
    JFrame parentFrame = (JFrame) SwingUtilities.getWindowAncestor((Component) evt.getSource());

    // Create an instance of ManageProducts (you can replace this with the actual reference you have)
    ManageProducts manageProductsRef = new ManageProducts();

     AddServiceDialog addServiceDialog = new AddServiceDialog(ManageProducts.this); // 'frame' is your parent JFrame
        addServiceDialog.setVisible(true); // Make the dialog visible

    }//GEN-LAST:event_add4ActionPerformed

    private void applyRightShadow(JPanel panel) {
    panel.setBorder(BorderFactory.createMatteBorder(
        0, 0, 0, 5, new Color(0, 0, 0, 30)
    ));
}

      public void populateServiceTable() {
        // Define column names
        String[] columnNames = {"Service ID", "Service Name", "Charge", "Service Type"};
        
        // DefaultTableModel to hold data
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        // Database query to fetch services data
        String query = "SELECT service_id, service_name, charge, service_type FROM services";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            // Iterate over the result set and add rows to the table model
            while (rs.next()) {
                int serviceId = rs.getInt("service_id");
                String serviceName = rs.getString("service_name");
                BigDecimal charge = rs.getBigDecimal("charge");
                String serviceType = rs.getString("service_type");

                // Add each row to the model
                model.addRow(new Object[] { serviceId, serviceName, charge, serviceType });
            }

            // Set the model to the JTable
            serviceTable.setModel(model);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading services data.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
   

    public static void main(String args[]) {
         /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

                try {
                    UIManager.setLookAndFeel(new FlatLightLaf()); // Or FlatIntelliJLaf, FlatDarkLaf
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                // Launch your frame
                SwingUtilities.invokeLater(() -> {
                    new ManageProducts().setVisible(true);
                });
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable ProductsTable;
    private javax.swing.JPanel SidebarMenu;
    private javax.swing.JButton add3;
    private javax.swing.JButton add4;
    private javax.swing.JPanel header;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable serviceTable;
    // End of variables declaration//GEN-END:variables

    private void applyShadow(JPanel jPanel1, int i, int i0, int i1, int i2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
