package admin;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.util.List;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import com.formdev.flatlaf.FlatIntelliJLaf;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import javax.swing.JComboBox;
import javax.swing.SpinnerDateModel;
import java.sql.*;
import admin.DatabaseConnection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.text.ParseException;


/**
 *
 * @author Kristine
 */
public class ServiceReservations extends javax.swing.JFrame {

    private JPanel calendarPanel;
    private JPanel reservationPanel;
    private JLabel selectedDateLabel;
    private JLabel monthYearLabel;
    private LocalDate selectedDate = LocalDate.now();
    private YearMonth currentYearMonth = YearMonth.now();
    private Map<LocalDate, List<String>> reservations = new HashMap<>();

    private Connection conn;

    public ServiceReservations() {
        initComponents();
        applyRightShadow(header);
        populateReservationsNowTable();

        calendarContainer.setBackground(Color.YELLOW);

        calendarContainer.setLayout(new BorderLayout()); // <- Add this line if needed
        JPanel calendarUI = createReservationCalendarPanel();
        calendarContainer.add(calendarUI);
        calendarContainer.revalidate();
        calendarContainer.repaint();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        header = new javax.swing.JPanel();
        SidebarMenu = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        calendarContainer = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        reservationsNowTable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        header1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(238, 239, 238));

        header.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout headerLayout = new javax.swing.GroupLayout(header);
        header.setLayout(headerLayout);
        headerLayout.setHorizontalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        headerLayout.setVerticalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        SidebarMenu.setBackground(new java.awt.Color(0, 96, 50));

        jButton1.setBackground(new java.awt.Color(0, 96, 50));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home (6).png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 51, 0));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/box-open.png"))); // NOI18N
        jButton2.setBorder(null);

        jButton4.setBackground(new java.awt.Color(0, 96, 50));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/newspaper.png"))); // NOI18N
        jButton4.setBorder(null);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(0, 96, 50));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/point-of-sale-bill.png"))); // NOI18N
        jButton5.setBorder(null);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(0, 96, 50));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/inventory-alt.png"))); // NOI18N
        jButton6.setBorder(null);

        jButton7.setBackground(new java.awt.Color(0, 96, 50));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/calendar-day.png"))); // NOI18N
        jButton7.setBorder(null);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SidebarMenuLayout = new javax.swing.GroupLayout(SidebarMenu);
        SidebarMenu.setLayout(SidebarMenuLayout);
        SidebarMenuLayout.setHorizontalGroup(
            SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SidebarMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(SidebarMenuLayout.createSequentialGroup()
                        .addGroup(SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE)
                            .addComponent(jButton7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        SidebarMenuLayout.setVerticalGroup(
            SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SidebarMenuLayout.createSequentialGroup()
                .addContainerGap(198, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(128, 128, 128))
        );

        javax.swing.GroupLayout calendarContainerLayout = new javax.swing.GroupLayout(calendarContainer);
        calendarContainer.setLayout(calendarContainerLayout);
        calendarContainerLayout.setHorizontalGroup(
            calendarContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 851, Short.MAX_VALUE)
        );
        calendarContainerLayout.setVerticalGroup(
            calendarContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );

        reservationsNowTable.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        reservationsNowTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Reservation ID", "Name", "Service Type", "Start Time", "End Time", "Type of Animal", "No. of Animals", "Status"
            }
        ));
        jScrollPane1.setViewportView(reservationsNowTable);

        jLabel1.setFont(new java.awt.Font("Poppins", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("Today's Reservations");

        header1.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout header1Layout = new javax.swing.GroupLayout(header1);
        header1.setLayout(header1Layout);
        header1Layout.setHorizontalGroup(
            header1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1250, Short.MAX_VALUE)
        );
        header1Layout.setVerticalGroup(
            header1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(SidebarMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(header, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(539, 539, 539)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1140, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(calendarContainer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(header1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(SidebarMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(header, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(450, 450, 450)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(calendarContainer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(header1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void populateReservationsNowTable() {
        // Get today's date in SQL format
        String todayDate = new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());

        // Prepare your table model
        DefaultTableModel tableModel = (DefaultTableModel) reservationsNowTable.getModel();

        // Clear the existing data
        tableModel.setRowCount(0);

        try (Connection conn = DatabaseConnection.getConnection()) {
            // SQL query to get today's reservations, join with the services table for service_name
            String sql = "SELECT sr.reservation_id, sr.name, s.service_name, sr.time_from, sr.time_to, sr.pet_type, sr.animal_count, sr.status "
                    + "FROM services_reservations sr "
                    + "JOIN services s ON sr.service_id = s.service_id "
                    + "WHERE sr.reservation_date = ?";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setDate(1, java.sql.Date.valueOf(todayDate));  // Set today's date in the query
                ResultSet rs = stmt.executeQuery();

                // SimpleDateFormat for converting SQL time to 12-hour format (AM/PM)
                SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");

                // Process each reservation and add to the table
                while (rs.next()) {
                    int reservationId = rs.getInt("reservation_id");
                    String name = rs.getString("name");
                    String service = rs.getString("service_name");  // Use service name from the services table

                    // Convert SQL time to formatted string (hh:mm a)
                    String timeFrom = timeFormat.format(rs.getTime("time_from"));
                    String timeTo = timeFormat.format(rs.getTime("time_to"));

                    String petType = rs.getString("pet_type");
                    int animalCount = rs.getInt("animal_count");
                    String status = rs.getString("status");

                    // Add the reservation data to the table
                    tableModel.addRow(new Object[]{reservationId, name, service, timeFrom, timeTo, petType, animalCount, status});
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading today's reservations: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }

        // Apply styles to the table
        styleTable();
    }

    private void styleTable() {
        // Set the table header background color and font
        JTableHeader header = reservationsNowTable.getTableHeader();
        header.setBackground(new Color(0, 96, 50));  // Green header background (Material Green 500)

        header.setForeground(Color.WHITE); // Header text color
        header.setFont(new Font("Arial", Font.BOLD, 12)); // Header font

        // Set row selection color
        reservationsNowTable.setSelectionBackground(new Color(173, 216, 230));  // Light blue selection

        // Set the table row height
        reservationsNowTable.setRowHeight(30);

        // Apply a custom cell renderer for the 'Status' column
        reservationsNowTable.getColumnModel().getColumn(7).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                // Apply custom coloring for the status column
                if (value != null) {
                    String status = value.toString().trim();  // Ensure no extra spaces

                    // Check status and apply background color accordingly
                    if (status.equalsIgnoreCase("Booked")) {
                        c.setBackground(new Color(144, 238, 144)); // Light green for 'Booked'
                        c.setForeground(Color.BLACK);  // Set text color to black
                    } else if (status.equalsIgnoreCase("Cancelled")) {
                        c.setBackground(new Color(255, 99, 71)); // Light red for 'Cancelled'
                        c.setForeground(Color.WHITE);  // Set text color to white
                    } else {
                        c.setBackground(Color.WHITE); // Default color for other statuses
                        c.setForeground(Color.BLACK);  // Text color
                    }
                }
                return c;
            }
        });

        // Center the text in all columns
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < reservationsNowTable.getColumnCount(); i++) {
            reservationsNowTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        // Optional: Set a custom font for the table
        reservationsNowTable.setFont(new Font("Arial", Font.PLAIN, 12));

        // Optional: Set column widths
        reservationsNowTable.getColumnModel().getColumn(0).setPreferredWidth(50);  // Reservation ID
        reservationsNowTable.getColumnModel().getColumn(1).setPreferredWidth(150); // Name
        reservationsNowTable.getColumnModel().getColumn(2).setPreferredWidth(100); // Service
        reservationsNowTable.getColumnModel().getColumn(3).setPreferredWidth(80);  // Time From
        reservationsNowTable.getColumnModel().getColumn(4).setPreferredWidth(80);  // Time To
        reservationsNowTable.getColumnModel().getColumn(5).setPreferredWidth(100); // Pet Type
        reservationsNowTable.getColumnModel().getColumn(6).setPreferredWidth(70);  // Animal Count
        reservationsNowTable.getColumnModel().getColumn(7).setPreferredWidth(100); // Status
    }

    private JPanel createReservationCalendarPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.X_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ==== Left: Calendar Section ====
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(BorderFactory.createTitledBorder("Calendar"));

        // Header (Month and Year with navigation)
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        headerPanel.setBackground(Color.WHITE);

        JButton prevBtn = new JButton("←");
        JButton nextBtn = new JButton("→");
        prevBtn.setFocusPainted(false);
        nextBtn.setFocusPainted(false);
        prevBtn.setBackground(new Color(0, 96, 50));
        prevBtn.setForeground(Color.WHITE);
        nextBtn.setBackground(new Color(0, 96, 50));
        nextBtn.setForeground(Color.WHITE);

        monthYearLabel = new JLabel();
        monthYearLabel.setFont(new Font("Arial", Font.BOLD, 16));
        headerPanel.add(prevBtn);
        headerPanel.add(monthYearLabel);
        headerPanel.add(nextBtn);

        calendarPanel = new JPanel(new GridLayout(7, 7, 5, 5)); // 7 rows: 1 for headers, 6 for dates
        calendarPanel.setPreferredSize(new Dimension(250, 300));
        calendarPanel.setMaximumSize(new Dimension(250, 300));

        // Add header and calendar directly without extra spacing
        leftPanel.add(headerPanel);  // This adds the header on top
        leftPanel.add(calendarPanel); // The calendar will now be directly below the header

        // ==== Right: Reservation Panel ====
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBorder(BorderFactory.createTitledBorder("Reservations"));
        rightPanel.setBackground(Color.WHITE);

        selectedDateLabel = new JLabel();
        selectedDateLabel.setFont(new Font("Poppins", Font.BOLD, 14));
        selectedDateLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        reservationPanel = new JPanel();
        reservationPanel.setLayout(new BoxLayout(reservationPanel, BoxLayout.Y_AXIS));

        JScrollPane scrollPane = new JScrollPane(reservationPanel);
        scrollPane.setPreferredSize(new Dimension(851, 200));

        JButton addBtn = new JButton("New Reservation");
        addBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        addBtn.addActionListener(e -> showAddReservationDialog());
        addBtn.setBackground(new Color(0, 96, 50));
        addBtn.setForeground(Color.WHITE);
        addBtn.setFont(new Font("Arial", Font.PLAIN, 12));
        addBtn.setFocusPainted(false);
        addBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        rightPanel.add(selectedDateLabel);
        rightPanel.add(Box.createVerticalStrut(5));
        rightPanel.add(scrollPane);
        rightPanel.add(Box.createVerticalStrut(10));
        rightPanel.add(addBtn);

        // ==== Navigation Buttons Logic ====
        prevBtn.addActionListener(e -> {
            currentYearMonth = currentYearMonth.minusMonths(1);
            renderCalendar(currentYearMonth);
        });

        nextBtn.addActionListener(e -> {
            currentYearMonth = currentYearMonth.plusMonths(1);
            renderCalendar(currentYearMonth);
        });

        // ==== Compose Layout ====
        mainPanel.add(leftPanel);
        mainPanel.add(Box.createHorizontalStrut(20));
        mainPanel.add(rightPanel);

        renderCalendar(currentYearMonth);
        updateReservationList();

        return mainPanel;
    }

    private void renderCalendar(YearMonth yearMonth) {

        loadReservationsForMonth(yearMonth); // <-- load all reservations for current month

        calendarPanel.removeAll();
        monthYearLabel.setText(yearMonth.getMonth().toString() + " " + yearMonth.getYear());

// Add day headers
        String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        for (String d : days) {
            JLabel lbl = new JLabel(d, SwingConstants.CENTER);
            lbl.setFont(new Font("Poppins", Font.BOLD, 11));
            lbl.setHorizontalAlignment(SwingConstants.CENTER);
            calendarPanel.add(lbl);
        }

// Start offset (0 = Sunday)
        LocalDate firstOfMonth = yearMonth.atDay(1);
        int startOffset = firstOfMonth.getDayOfWeek().getValue() % 7; // Sunday = 0

// Empty labels for offset
        for (int i = 0; i < startOffset; i++) {
            calendarPanel.add(new JLabel(""));
        }

// Add day buttons
        for (int day = 1; day <= yearMonth.lengthOfMonth(); day++) {
            LocalDate date = yearMonth.atDay(day);
            JButton btn = new JButton(String.valueOf(day));
            btn.setMargin(new Insets(0, 0, 0, 0)); // Remove excess spacing
            btn.setFocusPainted(false);
            btn.setPreferredSize(new Dimension(50, 50));
            btn.setFont(new Font("Poppins", Font.PLAIN, 11));
            btn.setContentAreaFilled(true);
            btn.setHorizontalAlignment(SwingConstants.CENTER);

            if (date.equals(selectedDate)) {
                btn.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
            }
            List<String> servicesForDate = reservations.get(date);
            if (servicesForDate != null && !servicesForDate.isEmpty()) {
                btn.setBackground(new Color(0xFFE4B5)); // light tan highlight
                btn.setToolTipText("Services: " + String.join(", ", servicesForDate));
            }

            btn.addActionListener(e -> {
                selectedDate = date;
                renderCalendar(currentYearMonth);
                updateReservationList();
            });

            calendarPanel.add(btn);
        }

// Ensure calendar grid is filled (49 cells)
        int totalCells = 7 * 7;
        int currentCells = calendarPanel.getComponentCount();
        for (int i = 0; i < totalCells - currentCells; i++) {
            calendarPanel.add(new JLabel(""));
        }

        calendarPanel.revalidate();
        calendarPanel.repaint();

    }

    private void loadReservationsForMonth(YearMonth yearMonth) {
        reservations.clear();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT sr.reservation_date, s.service_name "
                    + "FROM services_reservations sr "
                    + "JOIN services s ON sr.service_id = s.service_id "
                    + "WHERE MONTH(sr.reservation_date) = ? AND YEAR(sr.reservation_date) = ?";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, yearMonth.getMonthValue());
                stmt.setInt(2, yearMonth.getYear());

                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    LocalDate date = rs.getDate("reservation_date").toLocalDate();
                    String service = rs.getString("service_name");

                    reservations.computeIfAbsent(date, d -> new ArrayList<>()).add(service);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading calendar data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

   private void updateReservationList() {
    reservationPanel.removeAll();
    reservationPanel.setLayout(new BoxLayout(reservationPanel, BoxLayout.Y_AXIS));

    try (Connection conn = DatabaseConnection.getConnection()) {
        // Adjusted the query to reflect the current table structure
        String sql = "SELECT sr.reservation_id, sr.name, sr.contact, s.service_name, "
                   + "sr.home_service, sr.place, sr.pet_type, sr.animal_count, sr.status, "
                   + "sr.time_from, sr.time_to "
                   + "FROM services_reservations sr "
                   + "JOIN services s ON sr.service_id = s.service_id "
                   + "WHERE sr.reservation_date = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, java.sql.Date.valueOf(selectedDate));  // Make sure selectedDate is properly initialized
            ResultSet rs = stmt.executeQuery();

            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");

            while (rs.next()) {
                int id = rs.getInt("reservation_id");
                String name = rs.getString("name");
                String contact = rs.getString("contact");
                String service = rs.getString("service_name");
                boolean home = rs.getBoolean("home_service");
                String place = rs.getString("place");
                String pet = rs.getString("pet_type");
                int count = rs.getInt("animal_count");
                String status = rs.getString("status");

                // Format the time range
                String timeRange = (rs.getTime("time_from") != null ? sdf.format(rs.getTime("time_from")) : "N/A") 
                                 + " - " + (rs.getTime("time_to") != null ? sdf.format(rs.getTime("time_to")) : "N/A");

                // Create summary string
                String summary = String.format(
                        "<html><b>%s</b> (%s)<br>Service: %s<br>%s<br>Pet: %s (%d)<br>Time: %s<br>Status: %s</html>",
                        name, contact, service,
                        home ? "Home Service @ " + (place != null ? place : "N/A") : "Clinic Visit",
                        pet, count, timeRange, status
                );

                // Create panel for each reservation
                JPanel itemPanel = new JPanel();
                itemPanel.setLayout(new BoxLayout(itemPanel, BoxLayout.Y_AXIS));
                itemPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
                itemPanel.setBackground(new Color(245, 245, 245));

                JPanel topPanel = new JPanel(new BorderLayout());
                JCheckBox checkBox = new JCheckBox();
                checkBox.putClientProperty("reservationId", id);  // Store the reservation ID in the checkbox

                JLabel reservationLabel = new JLabel(summary);
                reservationLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                reservationLabel.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        showReservationDetailsDialog(id);  // Open details dialog when clicked
                    }
                });

                topPanel.add(checkBox, BorderLayout.WEST);
                topPanel.add(reservationLabel, BorderLayout.CENTER);
                topPanel.setOpaque(false);

                // Button panel for actions like Update and Cancel
                JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                buttonPanel.setOpaque(false);

                JButton updateBtn = new JButton("Update");
                JButton cancelBtn = new JButton("Cancel");

                updateBtn.addActionListener(e -> showUpdateDialog(id));  // Show update dialog
                cancelBtn.addActionListener(e -> markReservationAsCancelled(id));  // Mark reservation as cancelled

                buttonPanel.add(updateBtn);
                buttonPanel.add(cancelBtn);

                itemPanel.add(topPanel);
                itemPanel.add(Box.createVerticalStrut(5));
                itemPanel.add(buttonPanel);

                reservationPanel.add(itemPanel);
                reservationPanel.add(Box.createVerticalStrut(10));  // Add space between reservation items
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error loading reservations: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    }

    reservationPanel.revalidate();
    reservationPanel.repaint();
}

    private void markReservationAsCancelled(int reservationId) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "UPDATE services_reservations SET status = 'Cancelled' WHERE reservation_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, reservationId);
                int rows = stmt.executeUpdate();

                if (rows > 0) {
                    JOptionPane.showMessageDialog(this, "Reservation marked as cancelled.");
                    renderCalendar(currentYearMonth);
                    updateReservationList();
                } else {
                    JOptionPane.showMessageDialog(this, "Reservation not found.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

  private void showUpdateDialog(int reservationId) {
    // Fetch reservation data and pre-fill the update form
    try (Connection conn = DatabaseConnection.getConnection()) {
        String sql = "SELECT * FROM services_reservations WHERE reservation_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, reservationId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // Populate the fields with the reservation data
                String name = rs.getString("name");
                String contact = rs.getString("contact");
                int serviceId = rs.getInt("service_id");
                boolean homeService = rs.getBoolean("home_service");
                String place = rs.getString("place");
                String pet = rs.getString("pet_type");
                int count = rs.getInt("animal_count");
                Timestamp reservationTimeFrom = rs.getTimestamp("time_from");
                Timestamp reservationTimeTo = rs.getTimestamp("time_to");

                // Format the time values for display
                SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
                String timeFrom = (reservationTimeFrom != null) ? timeFormat.format(reservationTimeFrom) : "";
                String timeTo = (reservationTimeTo != null) ? timeFormat.format(reservationTimeTo) : "";

                // Use a dialog to allow the user to update the reservation
                JTextField nameField = new JTextField(name);
                JTextField contactField = new JTextField(contact);
                JCheckBox homeServiceCheck = new JCheckBox("Home Service", homeService);
                JTextField placeField = new JTextField(place);
                placeField.setEnabled(homeServiceCheck.isSelected());

                homeServiceCheck.addActionListener(e -> placeField.setEnabled(homeServiceCheck.isSelected()));

                // Service ComboBox (assuming it's a fixed list for this example)
                JComboBox<String> serviceCombo = new JComboBox<>(new String[]{"Deworming", "Vaccination", "Checkup", "Grooming", "Surgery", "Others"});
                // Pre-select the service
                serviceCombo.setSelectedIndex(serviceId - 1);  // Assuming service_id starts from 1

                JTextField petField = new JTextField(pet);
                JSpinner animalCountSpinner = new JSpinner(new SpinnerNumberModel(count, 1, 100, 1));

                // Time fields
                JTextField timeFromField = new JTextField(timeFrom);
                JTextField timeToField = new JTextField(timeTo);

                // Panel layout for the form
                JPanel panel = new JPanel(new GridBagLayout());
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.insets = new Insets(5, 5, 5, 5);
                gbc.anchor = GridBagConstraints.WEST;
                gbc.fill = GridBagConstraints.HORIZONTAL;

                int row = 0;
                // Add Name field
                gbc.gridx = 0;
                gbc.gridy = row;
                panel.add(new JLabel("Name:"), gbc);
                gbc.gridx = 1;
                panel.add(nameField, gbc);
                row++;

                // Add Contact field
                gbc.gridx = 0;
                gbc.gridy = row;
                panel.add(new JLabel("Contact Number:"), gbc);
                gbc.gridx = 1;
                panel.add(contactField, gbc);
                row++;

                // Add Service field
                gbc.gridx = 0;
                gbc.gridy = row;
                panel.add(new JLabel("Service:"), gbc);
                gbc.gridx = 1;
                panel.add(serviceCombo, gbc);
                row++;

                // Add Home Service checkbox
                gbc.gridx = 0;
                gbc.gridy = row;
                panel.add(homeServiceCheck, gbc);
                row++;

                // Add Place field
                gbc.gridx = 0;
                gbc.gridy = row;
                panel.add(new JLabel("Place:"), gbc);
                gbc.gridx = 1;
                panel.add(placeField, gbc);
                row++;

                // Add Pet Type field
                gbc.gridx = 0;
                gbc.gridy = row;
                panel.add(new JLabel("Pet Type:"), gbc);
                gbc.gridx = 1;
                panel.add(petField, gbc);
                row++;

                // Add Animal Count field
                gbc.gridx = 0;
                gbc.gridy = row;
                panel.add(new JLabel("No. of Animals:"), gbc);
                gbc.gridx = 1;
                panel.add(animalCountSpinner, gbc);
                row++;

                // Add Time From field
                gbc.gridx = 0;
                gbc.gridy = row;
                panel.add(new JLabel("Time From:"), gbc);
                gbc.gridx = 1;
                panel.add(timeFromField, gbc);
                row++;

                // Add Time To field
                gbc.gridx = 0;
                gbc.gridy = row;
                panel.add(new JLabel("Time To:"), gbc);
                gbc.gridx = 1;
                panel.add(timeToField, gbc);
                row++;

                // Show the update dialog
                int result = JOptionPane.showConfirmDialog(this, panel, "Update Reservation", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                if (result == JOptionPane.OK_OPTION) {
                    // Get updated data from fields
                    String updatedName = nameField.getText();
                    String updatedContact = contactField.getText();
                    String updatedService = (String) serviceCombo.getSelectedItem();
                    boolean updatedHomeService = homeServiceCheck.isSelected();
                    String updatedPlace = placeField.getText();
                    String updatedPet = petField.getText();
                    int updatedCount = (Integer) animalCountSpinner.getValue();
                    String updatedTimeFrom = timeFromField.getText();
                    String updatedTimeTo = timeToField.getText();

                    // Convert time strings back to Date or Timestamp format
                    Timestamp updatedTimeFromTimestamp = null;
                    Timestamp updatedTimeToTimestamp = null;
                    try {
                        updatedTimeFromTimestamp = new Timestamp(new SimpleDateFormat("hh:mm a").parse(updatedTimeFrom).getTime());
                        updatedTimeToTimestamp = new Timestamp(new SimpleDateFormat("hh:mm a").parse(updatedTimeTo).getTime());
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    // SQL query to update the reservation
                    String updateSql = "UPDATE services_reservations SET name = ?, contact = ?, service_id = ?, home_service = ?, place = ?, pet_type = ?, animal_count = ?, time_from = ?, time_to = ? WHERE reservation_id = ?";
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                        updateStmt.setString(1, updatedName);
                        updateStmt.setString(2, updatedContact);
                        updateStmt.setInt(3, serviceCombo.getSelectedIndex() + 1);  // Assuming service_id is an integer
                        updateStmt.setBoolean(4, updatedHomeService);
                        updateStmt.setString(5, updatedHomeService ? updatedPlace : null);
                        updateStmt.setString(6, updatedPet);
                        updateStmt.setInt(7, updatedCount);
                        updateStmt.setTimestamp(8, updatedTimeFromTimestamp);
                        updateStmt.setTimestamp(9, updatedTimeToTimestamp);
                        updateStmt.setInt(10, reservationId);
                        updateStmt.executeUpdate();

                        JOptionPane.showMessageDialog(this, "Reservation updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error updating reservation: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
    }
}


    private void showReservationDetailsDialog(int reservationId) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM services_reservations WHERE reservation_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, reservationId);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    String name = rs.getString("name");
                    String contact = rs.getString("contact");
                    String service = rs.getString("service");
                    boolean homeService = rs.getBoolean("home_service");
                    String place = rs.getString("place");
                    String pet = rs.getString("pet_type");
                    int count = rs.getInt("animal_count");

                    SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
                    String timeFrom = timeFormat.format(rs.getTime("time_from"));
                    String timeTo = timeFormat.format(rs.getTime("time_to"));
                    String timeRange = timeFrom + " - " + timeTo;

                    String message = String.format(
                            "<html><b>%s</b> (%s)<br>Service: %s<br>%s<br>Pet: %s (%d)<br>Time: %s</html>",
                            name,
                            contact,
                            service,
                            homeService ? "Home Service @ " + place : "Clinic Visit",
                            pet,
                            count,
                            timeRange
                    );

                    JOptionPane.showMessageDialog(this, message, "Reservation Details", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load reservation details: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showAddReservationDialog() {

        JTextField nameField = new JTextField(15);
        JTextField contactField = new JTextField(15);
        JCheckBox homeServiceCheck = new JCheckBox("Home Service?");
        JTextField placeField = new JTextField(15);
        placeField.setEnabled(false);

        homeServiceCheck.addActionListener(e -> placeField.setEnabled(homeServiceCheck.isSelected()));

        SpinnerDateModel fromModel = new SpinnerDateModel();
        JSpinner fromTime = new JSpinner(fromModel);
        fromTime.setEditor(new JSpinner.DateEditor(fromTime, "hh:mm a"));

        SpinnerDateModel toModel = new SpinnerDateModel();
        JSpinner toTime = new JSpinner(toModel);
        toTime.setEditor(new JSpinner.DateEditor(toTime, "hh:mm a"));

        String[] petOptions = {"Dog", "Cat", "Bird", "Pig", "Cow", "Goat", "Others"};
        JComboBox<String> petCombo = new JComboBox<>(petOptions);
        petCombo.setEditable(true);

        // Dynamic serviceCombo population from the database
        JComboBox<String> serviceCombo = new JComboBox<>();
        serviceCombo.setEditable(true);
        loadServices(serviceCombo);  // Method to load services dynamically

        JSpinner animalCountSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1;
        panel.add(nameField, gbc);
        row++;

        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("Contact Number:"), gbc);
        gbc.gridx = 1;
        panel.add(contactField, gbc);
        row++;

        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("Service:"), gbc);
        gbc.gridx = 1;
        panel.add(serviceCombo, gbc);
        row++;

        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(homeServiceCheck, gbc);
        row++;

        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("Place:"), gbc);
        gbc.gridx = 1;
        panel.add(placeField, gbc);
        row++;

        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("Time From:"), gbc);
        gbc.gridx = 1;
        panel.add(fromTime, gbc);
        row++;

        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("Time To:"), gbc);
        gbc.gridx = 1;
        panel.add(toTime, gbc);
        row++;

        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("Pet Type:"), gbc);
        gbc.gridx = 1;
        panel.add(petCombo, gbc);
        row++;

        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("No. of Animals:"), gbc);
        gbc.gridx = 1;
        panel.add(animalCountSpinner, gbc);

        int result = JOptionPane.showConfirmDialog(this, panel, "Add Reservation", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String name = nameField.getText().trim();
            String contact = contactField.getText().trim();
            String service = (String) serviceCombo.getSelectedItem();  // Get selected service name
            boolean isHome = homeServiceCheck.isSelected();
            String place = placeField.getText().trim();
            String pet = petCombo.getEditor().getItem().toString();
            int count = (Integer) animalCountSpinner.getValue();

            java.sql.Date sqlDate = java.sql.Date.valueOf(selectedDate);
            java.sql.Time sqlFromTime = new java.sql.Time(fromModel.getDate().getTime());
            java.sql.Time sqlToTime = new java.sql.Time(toModel.getDate().getTime());

            try (Connection conn = DatabaseConnection.getConnection()) {
                // Retrieve the service_id for the selected service
                String serviceSql = "SELECT service_id FROM services WHERE service_name = ?";
                try (PreparedStatement serviceStmt = conn.prepareStatement(serviceSql)) {
                    serviceStmt.setString(1, service);
                    ResultSet serviceRs = serviceStmt.executeQuery();
                    int serviceId = 0;

                    if (serviceRs.next()) {
                        serviceId = serviceRs.getInt("service_id");
                    }

                    // Insert reservation data into the database
                    String sql = "INSERT INTO services_reservations (reservation_date, name, contact, service_id, home_service, place, time_from, time_to, pet_type, animal_count) "
                            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setDate(1, sqlDate);
                        stmt.setString(2, name);
                        stmt.setString(3, contact);
                        stmt.setInt(4, serviceId);  // Store service_id instead of service name
                        stmt.setBoolean(5, isHome);
                        stmt.setString(6, isHome ? place : null);
                        stmt.setTime(7, sqlFromTime);
                        stmt.setTime(8, sqlToTime);
                        stmt.setString(9, pet);
                        stmt.setInt(10, count);
                        stmt.executeUpdate();
                    }

                    // Refresh calendar and panel from database
                    renderCalendar(currentYearMonth);
                    updateReservationList();

                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                Logger.getLogger(ServiceReservations.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void loadServices(JComboBox<String> serviceCombo) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT service_name FROM services";
            try (PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    serviceCombo.addItem(rs.getString("service_name"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading services", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public class ReservationDetails {

        public String name;
        public String contact;
        public boolean homeService;
        public String place;
        public String petType;
        public int petCount;
        public LocalTime timeFrom;
        public LocalTime timeTo;
    }


    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void applyRightShadow(JPanel panel) {
        panel.setBorder(BorderFactory.createMatteBorder(
                0, 0, 0, 5, new Color(0, 0, 0, 30)
        ));
    }

    public static void main(String args[]) {

        try {
            UIManager.setLookAndFeel(new FlatIntelliJLaf());
        } catch (Exception ex) {
            System.err.println("Failed to initialize FlatLaf");
        }

        SwingUtilities.invokeLater(() -> new ServiceReservations().setVisible(true));

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ServiceReservations().setVisible(true);
                SwingUtilities.invokeLater(ServiceReservations::new);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel SidebarMenu;
    private javax.swing.JPanel calendarContainer;
    private javax.swing.JPanel header;
    private javax.swing.JPanel header1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable reservationsNowTable;
    // End of variables declaration//GEN-END:variables
}
