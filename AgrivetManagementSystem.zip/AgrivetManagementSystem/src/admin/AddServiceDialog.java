package admin;

import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AddServiceDialog extends JDialog {

    private JTextField serviceNameField;
    private JTextField chargeField;
    private JComboBox<String> serviceTypeComboBox;

    public AddServiceDialog(Frame parent) {
        super(parent, "Add Service", true);

        // Set FlatLaf look and feel with Poppins font
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        }
        UIManager.put("defaultFont", new Font("Poppins", Font.PLAIN, 12));

        // Dialog properties
        setSize(420, 320);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);

        // Replace this section in your constructor
// Create a container panel with GridBagLayout
        JPanel container = new JPanel(new GridBagLayout());
        container.setBorder(new EmptyBorder(20, 30, 20, 30));
        container.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;

        JLabel titleLabel = new JLabel("Add New Service");
        titleLabel.setFont(new Font("Poppins", Font.BOLD, 16));
        titleLabel.setHorizontalAlignment(SwingConstants.LEFT);
        container.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridy++;

// Service Name
        container.add(new JLabel("Service Name:"), gbc);

        gbc.gridx = 1;
        serviceNameField = new JTextField(20);
        serviceNameField.setFont(new Font("Poppins", Font.PLAIN, 12));
        container.add(serviceNameField, gbc);

// Charge
        gbc.gridx = 0;
        gbc.gridy++;
        container.add(new JLabel("Charge:"), gbc);

        gbc.gridx = 1;
        chargeField = new JTextField(20);
        chargeField.setFont(new Font("Poppins", Font.PLAIN, 12));
        container.add(chargeField, gbc);

// Service Type
        gbc.gridx = 0;
        gbc.gridy++;
        container.add(new JLabel("Service Type:"), gbc);

        gbc.gridx = 1;
        serviceTypeComboBox = new JComboBox<>(new String[]{"Clinic", "Home"});
        serviceTypeComboBox.setFont(new Font("Poppins", Font.PLAIN, 12));
        container.add(serviceTypeComboBox, gbc);

// Buttons Panel
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.EAST;

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(Color.WHITE);

        JButton cancelButton = new JButton("Cancel");
        styleButton(cancelButton, Color.LIGHT_GRAY, Color.BLACK);
        cancelButton.addActionListener(e -> dispose());
        buttonPanel.add(cancelButton);

        JButton submitButton = new JButton("Add Service");
        styleButton(submitButton, new Color(0, 123, 255), Color.WHITE);
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String serviceName = serviceNameField.getText().trim();
                String chargeText = chargeField.getText().trim();
                String serviceType = (String) serviceTypeComboBox.getSelectedItem();

                if (serviceName.isEmpty() || chargeText.isEmpty()) {
                    JOptionPane.showMessageDialog(AddServiceDialog.this, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    try {
                        double charge = Double.parseDouble(chargeText);
                        addServiceToDatabase(serviceName, charge, serviceType);
                        dispose();
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(AddServiceDialog.this, "Please enter a valid charge.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        buttonPanel.add(submitButton);
        container.add(buttonPanel, gbc);

        add(container);
    }

    // Helper to create panels for input fields with labels
    private JPanel createFieldPanel(String labelText, JTextField textField) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Poppins", Font.PLAIN, 12));
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(label, gbc);

        textField.setFont(new Font("Poppins", Font.PLAIN, 12));
        textField.setPreferredSize(new Dimension(200, 28));
        gbc.gridx = 1;
        panel.add(textField, gbc);

        return panel;
    }

    // Helper to style buttons consistently
    private void styleButton(JButton button, Color bg, Color fg) {
        button.setPreferredSize(new Dimension(110, 35));
        button.setBackground(bg);
        button.setForeground(fg);
        button.setFocusPainted(false);
        button.setFont(new Font("Poppins", Font.PLAIN, 12));
    }

    // Method to add service to the database
    private void addServiceToDatabase(String serviceName, double charge, String serviceType) {
        String query = "INSERT INTO services (service_name, charge, service_type) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(query)) {

            pst.setString(1, serviceName);
            pst.setDouble(2, charge);
            pst.setString(3, serviceType);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Service added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding service to database.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Example main method to test the dialog
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Add Service Example");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(300, 200);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

            AddServiceDialog dialog = new AddServiceDialog(frame);
            dialog.setVisible(true);
        });
    }
}
