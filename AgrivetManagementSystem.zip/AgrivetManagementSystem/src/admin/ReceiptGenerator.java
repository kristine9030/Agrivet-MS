package admin; 
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.text.DecimalFormat;

public class ReceiptGenerator {

    private static final int MAX_NAME_LENGTH = 18; // Adjust as needed
    private static final int MAX_VALUE_LENGTH = 15; // Adjust for total, paid, change

    // Method to abbreviate item name if it's too long
    private String abbreviateItemName(String name) {
        if (name.length() > MAX_NAME_LENGTH) {
            return name.substring(0, MAX_NAME_LENGTH - 3) + "...";  // Truncate and add "..."
        }
        return name;
    }

    // Method to format monetary values to fit within the fixed width
    private String formatAmount(double amount) {
        return String.format("%-" + MAX_VALUE_LENGTH + ".2f", amount); // Left-align with 2 decimal places
    }

    public void onPaymentSuccess(int saleId, Connection conn, String loggedInUser) {
        try {
            // Set the discount to 0 temporarily for the package admin
            double discount = 0.0;  // Discount set to 0 for now

            // Generate a control number for the receipt
            String controlNumber = "RCPT-" + (System.currentTimeMillis() % 100000);

            JTextArea receiptArea = new JTextArea();
            receiptArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
            receiptArea.setEditable(false);
            receiptArea.setBackground(Color.WHITE);

            StringBuilder receipt = new StringBuilder();
            receipt.append("=====================================================\n");
            receipt.append("                    PACIFICA STORE\n");
            receipt.append("               3JCJ+PMV, P. Rinoza St.\n");
            receipt.append("                    Nasugbu, Batangas\n");
            receipt.append("               Pacifica Agrivet Supplies, Inc.\n");
            receipt.append("=====================================================\n");
            receipt.append("Sales Invoice #: ").append(controlNumber).append("\n");
            receipt.append("Cashier: ").append(loggedInUser).append("\n");
            receipt.append("-------------------------------------------------------\n");
            receipt.append("Qty    Description(s)             Price\n");
            receipt.append("-------------------------------------------------------\n");

            // Fetch sale details
            PreparedStatement psSale = conn.prepareStatement("SELECT * FROM sales WHERE id = ?");
            psSale.setInt(1, saleId);
            ResultSet rsSale = psSale.executeQuery();

            Timestamp saleDate = null;
            double total = 0, paid = 0, change = 0;
            if (rsSale.next()) {
                saleDate = rsSale.getTimestamp("sale_date");
                total = rsSale.getDouble("total_amount");
                paid = rsSale.getDouble("amount_paid");
                change = rsSale.getDouble("change_due");

                receipt.append("Sale Date: ").append(saleDate).append("\n");
            }

            // Fetch sale items and their product details
            PreparedStatement psItems = conn.prepareStatement(
                "SELECT si.name, si.quantity, si.price, si.total " +
                "FROM sales_items si " +
                "WHERE si.sale_id = ?"
            );
            psItems.setInt(1, saleId);
            ResultSet rsItems = psItems.executeQuery();

            while (rsItems.next()) {
                String name = rsItems.getString("name");
                int qty = rsItems.getInt("quantity");
                double unitPrice = rsItems.getDouble("price");
                double itemTotal = rsItems.getDouble("total");

                // Abbreviate the name if it exceeds the allowed length
                name = abbreviateItemName(name);

                // Format the monetary values to ensure alignment
                String formattedUnitPrice = formatAmount(unitPrice);
                String formattedItemTotal = formatAmount(itemTotal);

                receipt.append(String.format("%-20s\n", name)); // Full name of the product
                receipt.append(String.format("          (%3d QTY)   @%s     %s\n", qty, formattedUnitPrice, formattedItemTotal));
            }

            receipt.append("-------------------------------------------------------\n");

            // Format total, paid, and change to fit the receipt layout
            String formattedTotal = formatAmount(total);
            String formattedPaid = formatAmount(paid);
            String formattedChange = formatAmount(change);
            String formattedDiscount = formatAmount(discount);

            // If discount is greater than 0, print it (for now, discount is 0)
            if (discount > 0) {
                receipt.append(String.format("Discount:        %-" + MAX_VALUE_LENGTH + "s\n", formattedDiscount));
            }

            receipt.append(String.format("TOTAL:           %-" + MAX_VALUE_LENGTH + "s\n", formattedTotal));
            receipt.append(String.format("PAID:            %-" + MAX_VALUE_LENGTH + "s\n", formattedPaid));
            receipt.append(String.format("CHANGE:          %-" + MAX_VALUE_LENGTH + "s\n", formattedChange));

            receipt.append("=====================================================\n");
            receipt.append("                 THANK YOU FOR SHOPPING!\n");
            receipt.append("                Please come again soon!\n");
            receipt.append("=====================================================\n");

            receiptArea.setText(receipt.toString());

            JPanel panel = new JPanel(new BorderLayout());
            panel.setBackground(Color.WHITE);
            panel.add(new JScrollPane(receiptArea), BorderLayout.CENTER);

            int option = JOptionPane.showConfirmDialog(null, panel, "Receipt",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (option == JOptionPane.OK_OPTION) {
                receiptArea.print();
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error generating receipt: " + e.getMessage());
        }
    }
}
