/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package admin;
import java.awt.*;
import javax.swing.border.AbstractBorder;

public class ShadowBorder extends AbstractBorder {
    private final int shadowSize;
    private final Color shadowColor;
    private final float opacity;

    public ShadowBorder() {
        this(new Color(0, 0, 0), 8, 0.15f);
    }

    public ShadowBorder(Color shadowColor, int shadowSize, float opacity) {
        this.shadowColor = shadowColor;
        this.shadowSize = shadowSize;
        this.opacity = opacity;
    }

    @Override
    public Insets getBorderInsets(Component c) {
        return new Insets(shadowSize, shadowSize, shadowSize, shadowSize);
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        Graphics2D g2 = (Graphics2D) g.create();
        int size = shadowSize;

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Color transparent = new Color(shadowColor.getRed(), shadowColor.getGreen(), shadowColor.getBlue(), (int) (255 * opacity));

        for (int i = 0; i < size; i++) {
            g2.setColor(new Color(transparent.getRed(), transparent.getGreen(), transparent.getBlue(), (int) ((opacity * 255) * (1 - (i / (float) size)))));
            g2.drawRoundRect(x + i, y + i, width - i * 2 - 1, height - i * 2 - 1, 20, 20);
        }

        g2.dispose();
    }
}
