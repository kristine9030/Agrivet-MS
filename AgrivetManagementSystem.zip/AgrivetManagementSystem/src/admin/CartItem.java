package admin;

import java.math.BigDecimal;

public class CartItem {

    private String productId;
    private int quantity;
    private BigDecimal unitPrice;
    private BigDecimal totalPrice;

    // Constructor to initialize productId, quantity, and unitPrice
    public CartItem(String productId, int quantity, BigDecimal unitPrice) {
        this.productId = productId;
        this.quantity = quantity;
        this.unitPrice = unitPrice;

        // Recalculate total price each time an item is added
        updateTotalPrice();
    }

    // Method to update the total price based on quantity and unit price
    public void updateTotalPrice() {
        this.totalPrice = unitPrice.multiply(new BigDecimal(quantity));
    }

    // Getters
    public String getProductId() {
        return productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    // Setter for quantity, automatically updates total price
    public void setQuantity(int quantity) {
        this.quantity = quantity;
        updateTotalPrice();  // Recalculate totalPrice whenever quantity changes
    }

    // Setter for unit price, automatically updates total price
    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
        updateTotalPrice();  // Recalculate totalPrice whenever unitPrice changes
    }

    // Override toString for better readability
    @Override
    public String toString() {
        return "Product ID: " + productId + ", Quantity: " + quantity + ", Unit Price: " + unitPrice + ", Total Price: " + totalPrice;
    }
}
