
package admin;

import javax.swing.*;
import java.awt.*;
import java.math.BigDecimal;

public class ProductCard extends JPanel {

    private final String productId;
    private final String name;
    private final int stocks;
    private final BigDecimal price;

    public ProductCard(String productId, String name, int stocks, BigDecimal price) {
        this.productId = productId;
        this.name = name;
        this.stocks = stocks;
        this.price = price;

        initUI();
    }

    private void initUI() {
        setLayout(new GridLayout(4, 1));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(10, 10, 10, 10),
                BorderFactory.createLineBorder(Color.GRAY, 1)
        ));

        add(new JLabel("Product ID: " + productId));
        add(new JLabel("Name: " + name));
        add(new JLabel("Stocks: " + stocks));
        add(new JLabel("Price: ₱" + price));

        setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
    }

    // Optional getters
    public String getProductId() {
        return productId;
    }
}

