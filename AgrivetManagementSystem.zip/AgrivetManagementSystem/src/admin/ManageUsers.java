package admin;

import admin.DatabaseConnection;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.sql.*;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author Kristine
 */
public class ManageUsers extends javax.swing.JFrame {

    private Connection conn;
    private String imagePath = "";
    private File selectedFile;

    private final Map<Integer, Color> rowColors = new HashMap<>();

    public ManageUsers() {
        initComponents();
        generateSRCode();
        populateUsersTable();
        styleUsersTable();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        header = new javax.swing.JPanel();
        SidebarMenu = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txtImagePath = new javax.swing.JLabel();
        BrowseButton = new javax.swing.JButton();
        firstNameField = new javax.swing.JTextField();
        roleBox = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        accCodeTextField = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        middleNameField = new javax.swing.JTextField();
        lastNameField = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        add1 = new javax.swing.JButton();
        add2 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        usersTable = new javax.swing.JTable();
        middleNameTextField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        add = new javax.swing.JButton();
        add3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(238, 239, 238));

        header.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout headerLayout = new javax.swing.GroupLayout(header);
        header.setLayout(headerLayout);
        headerLayout.setHorizontalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1190, Short.MAX_VALUE)
        );
        headerLayout.setVerticalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        SidebarMenu.setBackground(new java.awt.Color(0, 96, 50));

        jButton1.setBackground(new java.awt.Color(0, 96, 50));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home (6).png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 51, 0));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/box-open.png"))); // NOI18N
        jButton2.setBorder(null);

        jButton4.setBackground(new java.awt.Color(0, 96, 50));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/newspaper.png"))); // NOI18N
        jButton4.setBorder(null);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(0, 96, 50));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/point-of-sale-bill.png"))); // NOI18N
        jButton5.setBorder(null);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(0, 96, 50));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/inventory-alt.png"))); // NOI18N
        jButton6.setBorder(null);

        jButton7.setBackground(new java.awt.Color(0, 96, 50));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/calendar-day.png"))); // NOI18N
        jButton7.setBorder(null);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SidebarMenuLayout = new javax.swing.GroupLayout(SidebarMenu);
        SidebarMenu.setLayout(SidebarMenuLayout);
        SidebarMenuLayout.setHorizontalGroup(
            SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SidebarMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(SidebarMenuLayout.createSequentialGroup()
                        .addGroup(SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE)
                            .addComponent(jButton7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        SidebarMenuLayout.setVerticalGroup(
            SidebarMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SidebarMenuLayout.createSequentialGroup()
                .addContainerGap(198, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(137, 137, 137))
        );

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel9.setBackground(new java.awt.Color(246, 247, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(153, 153, 153)));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setBackground(new java.awt.Color(238, 238, 238));
        jLabel15.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel15.setText("Role");
        jPanel9.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 420, 40, 30));

        jLabel17.setBackground(new java.awt.Color(102, 102, 102));
        jLabel17.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel17.setText("First Name");
        jPanel9.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 80, 30));

        txtImagePath.setBackground(new java.awt.Color(153, 153, 153));
        txtImagePath.setForeground(new java.awt.Color(153, 153, 153));
        txtImagePath.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(51, 51, 51)));
        jPanel9.add(txtImagePath, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, 149, 140));

        BrowseButton.setBackground(new java.awt.Color(172, 56, 52));
        BrowseButton.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        BrowseButton.setForeground(new java.awt.Color(255, 255, 255));
        BrowseButton.setText("Browse");
        BrowseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BrowseButtonActionPerformed(evt);
            }
        });
        jPanel9.add(BrowseButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 210, 100, 30));

        firstNameField.setBackground(new java.awt.Color(238, 238, 238));
        firstNameField.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        firstNameField.setForeground(new java.awt.Color(51, 51, 51));
        jPanel9.add(firstNameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, 300, 30));

        roleBox.setBackground(new java.awt.Color(238, 238, 238));
        roleBox.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        roleBox.setForeground(new java.awt.Color(51, 51, 51));
        roleBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Cashier", "Admin" }));
        jPanel9.add(roleBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 420, 150, 30));

        jLabel18.setBackground(new java.awt.Color(102, 102, 102));
        jLabel18.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel18.setText("Account Code");
        jPanel9.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, -1, 30));

        accCodeTextField.setEditable(false);
        accCodeTextField.setBackground(new java.awt.Color(238, 238, 238));
        accCodeTextField.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        accCodeTextField.setForeground(new java.awt.Color(51, 51, 51));
        jPanel9.add(accCodeTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 260, 190, 30));

        jLabel21.setBackground(new java.awt.Color(102, 102, 102));
        jLabel21.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel21.setText("Middle Name");
        jPanel9.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 100, 30));

        middleNameField.setBackground(new java.awt.Color(238, 238, 238));
        middleNameField.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        middleNameField.setForeground(new java.awt.Color(51, 51, 51));
        jPanel9.add(middleNameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 340, 300, 30));

        lastNameField.setBackground(new java.awt.Color(238, 238, 238));
        lastNameField.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        lastNameField.setForeground(new java.awt.Color(51, 51, 51));
        jPanel9.add(lastNameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 380, 300, 30));

        jLabel22.setBackground(new java.awt.Color(102, 102, 102));
        jLabel22.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        jLabel22.setText("Last Name");
        jPanel9.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, 100, 30));

        add1.setBackground(new java.awt.Color(204, 153, 0));
        add1.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        add1.setForeground(new java.awt.Color(255, 255, 255));
        add1.setText("Cancel");
        add1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add1ActionPerformed(evt);
            }
        });
        jPanel9.add(add1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 490, 110, 30));

        add2.setBackground(new java.awt.Color(0, 128, 55));
        add2.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        add2.setForeground(new java.awt.Color(255, 255, 255));
        add2.setText("Save");
        add2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add2ActionPerformed(evt);
            }
        });
        jPanel9.add(add2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 490, 170, 30));

        jPanel2.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 440, 570));

        jPanel10.setBackground(new java.awt.Color(246, 247, 255));
        jPanel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        usersTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Account Code", "Full Name", "Role", "Date Created"
            }
        ));
        usersTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usersTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(usersTable);

        jPanel10.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 680, 440));

        middleNameTextField.setBackground(new java.awt.Color(238, 238, 238));
        middleNameTextField.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        middleNameTextField.setForeground(new java.awt.Color(51, 51, 51));
        jPanel10.add(middleNameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 80, 300, 30));

        jLabel6.setBackground(new java.awt.Color(102, 102, 102));
        jLabel6.setFont(new java.awt.Font("Poppins", 0, 24)); // NOI18N
        jLabel6.setText("Accounts");
        jPanel10.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 200, 30));

        add.setBackground(new java.awt.Color(0, 128, 55));
        add.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        add.setForeground(new java.awt.Color(255, 255, 255));
        add.setText("Archives");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        jPanel10.add(add, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 90, 30));

        add3.setBackground(new java.awt.Color(0, 128, 55));
        add3.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        add3.setForeground(new java.awt.Color(255, 255, 255));
        add3.setText("Search");
        add3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add3ActionPerformed(evt);
            }
        });
        jPanel10.add(add3, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 80, 90, 30));

        jPanel2.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 30, 700, 570));

        jTabbedPane1.addTab("Manage Products ", jPanel2);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(SidebarMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(header, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1168, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(SidebarMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(header, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 643, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void populateUsersTable() {
        DefaultTableModel model = (DefaultTableModel) usersTable.getModel();
        model.setRowCount(0); // Clear existing rows

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Updated SQL to join users with roles
            String sql = "SELECT a.account_code, a.first_name, a.middle_name, a.last_name, r.role_name, u.date_created "
                    + "FROM accounts a "
                    + // Added space after 'accounts a'
                    "INNER JOIN users u ON a.account_code = u.account_code "
                    + // Added space before INNER JOIN
                    "INNER JOIN roles r ON u.role_id = r.role_id"; // Added space before INNER JOIN

            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String accountCode = rs.getString("account_code");
                String firstName = rs.getString("first_name");
                String middleName = rs.getString("middle_name");
                String lastName = rs.getString("last_name");
                String role = rs.getString("role_name"); // Now fetching role_name

                Timestamp dateCreated = rs.getTimestamp("date_created");

                // Optional: Combine full name
                String fullName = firstName + (middleName != null && !middleName.isEmpty() ? " " + middleName : "") + " " + lastName;

                // Add the row to the table with the full name and role_name
                model.addRow(new Object[]{accountCode, fullName, role, dateCreated});
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading users: " + e.getMessage());
        }
    }


    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void BrowseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BrowseButtonActionPerformed
        JFileChooser jf = new JFileChooser();
        jf.setDialogTitle("Select an Image");
        jf.setFileSelectionMode(JFileChooser.FILES_ONLY);

        int returnValue = jf.showOpenDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = jf.getSelectedFile();
            if (selectedFile != null) {
                imagePath = selectedFile.getAbsolutePath(); // Store selected image path
                setImagePath(imagePath); // Call method to display image
            }
        } else {
            JOptionPane.showMessageDialog(this, "No image selected.", "Warning", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_BrowseButtonActionPerformed

    private void generateSRCode() {
        try {
            // Get connection from DatabaseConnection class
            Connection conn = DatabaseConnection.getConnection();

            // SQL Query to get the last SR-Code from the users table
            String query = "SELECT account_code FROM users ORDER BY user_id DESC LIMIT 1";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            String newSRCode;
            if (rs.next()) {
                // Get the last SR-Code and increment it
                String lastSRCode = rs.getString("account_code");
                int lastNumber = Integer.parseInt(lastSRCode.substring(4)); // Extract the numeric part
                newSRCode = "2025" + String.format("%04d", lastNumber + 1); // Increment and format with leading zeros
            } else {
                // If no records exist, start from 20240001
                newSRCode = "20250001";
            }

            // Set the generated SR-Code in the text field
            accCodeTextField.setText(newSRCode);

            // Close resources
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error generating SR-Code: " + ex.getMessage());
        }
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;

        // Debugging: Print the selected path
        System.out.println("Selected Image Path: " + imagePath);

        if (imagePath != null && !imagePath.isEmpty()) {
            try {
                ImageIcon imageIcon = new ImageIcon(imagePath);
                Image img = imageIcon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                txtImagePath.setIcon(new ImageIcon(img));
                txtImagePath.setText(""); // Clear text when image is displayed
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error loading image!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            txtImagePath.setText("No Image Selected"); // Set default text if no image is selected
        }
    }


    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        showArchiveDialog();

    }//GEN-LAST:event_addActionPerformed

    private void styleUsersTable() {
        JTableHeader header = usersTable.getTableHeader();
        header.setBackground(new Color(0, 96, 50)); // Dark green header
        header.setForeground(Color.WHITE);          // White text for header
        header.setFont(new Font("Arial", Font.BOLD, 12));

        // Row styling
        usersTable.setSelectionBackground(new Color(173, 216, 230)); // Light blue for selected row
        usersTable.setRowHeight(30);
        usersTable.setFont(new Font("Arial", Font.PLAIN, 12));

        // Center-align all columns
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < usersTable.getColumnCount(); i++) {
            usersTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        // Optional: Set custom column widths (adjust based on your actual column count and preference)
        usersTable.getColumnModel().getColumn(0).setPreferredWidth(100);  // account_code
        usersTable.getColumnModel().getColumn(1).setPreferredWidth(200);  // full name
        usersTable.getColumnModel().getColumn(2).setPreferredWidth(80);   // role
        usersTable.getColumnModel().getColumn(3).setPreferredWidth(150);  // date_created
    }

    private void add1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add1ActionPerformed

        accCodeTextField.setText("");
        firstNameField.setText("");
        middleNameField.setText("");
        lastNameField.setText("");
        roleBox.setSelectedIndex(0); // Assumes the first item is the default (e.g., "Select Role")

        // Clear image preview and reset imagePath
        txtImagePath.setIcon(null); // if you're displaying image in a JLabel
        imagePath = null;
    }//GEN-LAST:event_add1ActionPerformed

    private void add2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add2ActionPerformed

        String accountCode = accCodeTextField.getText().trim();
        String firstName = firstNameField.getText().trim();
        String middleName = middleNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String role = roleBox.getSelectedItem().toString();
        FileInputStream fis = null;

        String fullName = firstName + (middleName.isEmpty() ? " " : " " + middleName + " ") + lastName;
        String password = lastName + "123";

        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false); // Start transaction

            // 1. Insert into accounts
            String insertAccount = "INSERT INTO accounts (account_code, first_name, middle_name, last_name, password, profile_image) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement accStmt = conn.prepareStatement(insertAccount)) {
                accStmt.setString(1, accountCode);
                accStmt.setString(2, firstName);
                accStmt.setString(3, middleName.isEmpty() ? null : middleName);
                accStmt.setString(4, lastName);
                accStmt.setString(5, password);

                if (imagePath != null && !imagePath.isEmpty()) {
                    File imageFile = new File(imagePath);
                    fis = new FileInputStream(imageFile);
                    accStmt.setBinaryStream(6, fis, (int) imageFile.length());
                } else {
                    accStmt.setNull(6, java.sql.Types.BLOB);
                }

                accStmt.executeUpdate();
            }

            // 2. Get role_id from roles table
            int roleId = -1;
            String roleQuery = "SELECT role_id FROM roles WHERE role_name = ?";
            try (PreparedStatement roleStmt = conn.prepareStatement(roleQuery)) {
                roleStmt.setString(1, role);
                try (ResultSet rs = roleStmt.executeQuery()) {
                    if (rs.next()) {
                        roleId = rs.getInt("role_id");
                    } else {
                        throw new SQLException("Role not found: " + role);
                    }
                }
            }

            // 3. Insert into users
            String insertUser = "INSERT INTO users (account_code, role_id, date_created) VALUES (?, ?, NOW())";
            try (PreparedStatement userStmt = conn.prepareStatement(insertUser)) {
                userStmt.setString(1, accountCode);
                userStmt.setInt(2, roleId);
                userStmt.executeUpdate();
            }

            conn.commit(); // ✅ All good
            populateUsersTable();

            JOptionPane.showMessageDialog(this, "Hi " + fullName + "!\nHere are your account details:\n"
                    + "Username: " + accountCode + "\nPassword: " + password
                    + "\n\nReminders: You must change your password for better security.");

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }//GEN-LAST:event_add2ActionPerformed

    private void usersTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usersTableMouseClicked
        int selectedRow = usersTable.getSelectedRow();
        if (selectedRow >= -1) {
            String accountCode = usersTable.getValueAt(selectedRow, 0).toString(); // account_code
            String fullName = usersTable.getValueAt(selectedRow, 1).toString();

            int choice = JOptionPane.showOptionDialog(
                    null,
                    "What do you want to do with this account: " + fullName + "?",
                    "Choose Action",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    new String[]{"Edit", "Delete"},
                    "Edit"
            );

            if (choice == 0) {
                // Edit
                openEditDialog(accountCode);
            } else if (choice == 1) {
                // Delete
                moveToArchiveAndDelete(accountCode);
            }
        }

    }//GEN-LAST:event_usersTableMouseClicked

    private void add3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_add3ActionPerformed

    private void openEditDialog(String accountCode) {
    try (Connection conn = DatabaseConnection.getConnection()) {
        // Step 1: Retrieve account and role info using JOIN
        String query = "SELECT a.first_name, a.middle_name, a.last_name, a.password, u.role_id " +
                       "FROM accounts a " +
                       "JOIN users u ON a.account_code = u.account_code " +
                       "WHERE a.account_code = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, accountCode);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            // Extract current data
            String firstNameVal = rs.getString("first_name");
            String middleNameVal = rs.getString("middle_name");
            String lastNameVal = rs.getString("last_name");
            String passwordVal = rs.getString("password");
            int currentRoleId = rs.getInt("role_id");

            // Fetch all roles for combo box
            Map<Integer, String> roleMap = new HashMap<>();
            JComboBox<String> roleComboBox = new JComboBox<>();

            String rolesQuery = "SELECT role_id, role_name FROM roles";
            try (PreparedStatement rolesStmt = conn.prepareStatement(rolesQuery);
                 ResultSet rolesRs = rolesStmt.executeQuery()) {
                while (rolesRs.next()) {
                    int roleId = rolesRs.getInt("role_id");
                    String roleName = rolesRs.getString("role_name");
                    roleMap.put(roleId, roleName);
                    roleComboBox.addItem(roleName);
                }
            }

            roleComboBox.setSelectedItem(roleMap.get(currentRoleId));

            // Editable fields
            JTextField firstName = new JTextField(firstNameVal);
            JTextField middleName = new JTextField(middleNameVal);
            JTextField lastName = new JTextField(lastNameVal);
            JTextField password = new JTextField(passwordVal);

            JPanel panel = new JPanel(new GridLayout(0, 1));
            panel.add(new JLabel("First Name:"));
            panel.add(firstName);
            panel.add(new JLabel("Middle Name:"));
            panel.add(middleName);
            panel.add(new JLabel("Last Name:"));
            panel.add(lastName);
            panel.add(new JLabel("Role:"));
            panel.add(roleComboBox);
            panel.add(new JLabel("Password:"));
            panel.add(password);

            int result = JOptionPane.showConfirmDialog(null, panel, "Edit Account Details",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                // Get selected role_id from map
                int selectedRoleId = roleMap.entrySet().stream()
                        .filter(e -> e.getValue().equals(roleComboBox.getSelectedItem()))
                        .map(Map.Entry::getKey)
                        .findFirst()
                        .orElse(-1);

                // Step 2a: Update accounts table (name and password)
                String updateAccount = "UPDATE accounts SET first_name=?, middle_name=?, last_name=?, password=? WHERE account_code=?";
                PreparedStatement updateAccountStmt = conn.prepareStatement(updateAccount);
                updateAccountStmt.setString(1, firstName.getText());
                updateAccountStmt.setString(2, middleName.getText());
                updateAccountStmt.setString(3, lastName.getText());
                updateAccountStmt.setString(4, password.getText());
                updateAccountStmt.setString(5, accountCode);
                updateAccountStmt.executeUpdate();

                // Step 2b: Update role in users table
                String updateRole = "UPDATE users SET role_id=? WHERE account_code=?";
                PreparedStatement updateRoleStmt = conn.prepareStatement(updateRole);
                updateRoleStmt.setInt(1, selectedRoleId);
                updateRoleStmt.setString(2, accountCode);
                updateRoleStmt.executeUpdate();

                JOptionPane.showMessageDialog(null, "User updated successfully!");
                populateUsersTable();
            }

        } else {
            JOptionPane.showMessageDialog(null, "User not found.");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}


   private void moveToArchiveAndDelete(String accountCode) {
    try (Connection conn = DatabaseConnection.getConnection()) {
        conn.setAutoCommit(false);

        // Check if user exists
        String selectQuery = "SELECT * FROM users WHERE account_code = ?";
        PreparedStatement selectStmt = conn.prepareStatement(selectQuery);
        selectStmt.setString(1, accountCode);
        ResultSet rs = selectStmt.executeQuery();

        if (rs.next()) {
            int roleId = rs.getInt("role_id");
            Timestamp dateCreated = rs.getTimestamp("date_created");

            // Insert into archive_users
            String insertArchive = "INSERT INTO archive_users (account_code, role_id, date_created, date_archived) VALUES (?, ?, ?, CURRENT_TIMESTAMP)";
            PreparedStatement archiveStmt = conn.prepareStatement(insertArchive);
            archiveStmt.setString(1, accountCode);
            archiveStmt.setInt(2, roleId);
            archiveStmt.setTimestamp(3, dateCreated);
            archiveStmt.executeUpdate();

            // Delete from users
            String deleteUser = "DELETE FROM users WHERE account_code = ?";
            PreparedStatement deleteStmt = conn.prepareStatement(deleteUser);
            deleteStmt.setString(1, accountCode);
            deleteStmt.executeUpdate();

            conn.commit();
            JOptionPane.showMessageDialog(null, "User archived and deleted successfully.");
            populateUsersTable();
        } else {
            JOptionPane.showMessageDialog(null, "User not found.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    private void showArchiveDialog() {
        JDialog dialog = new JDialog(this, "Archived Users", true);
        dialog.setSize(950, 500);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        DefaultTableModel model = new DefaultTableModel();
        JTable archiveTable = new JTable(model);

        model.setColumnIdentifiers(new String[]{
            "Account Code", "First Name", "Middle Name", "Last Name",
            "Role", "Password", "Date Created", "Date Archived"
        });

        loadArchivedUsers(model);

        JScrollPane scrollPane = new JScrollPane(archiveTable);
        dialog.add(scrollPane, BorderLayout.CENTER);

        // Restore button
        JButton restoreButton = new JButton("Restore Selected");
        restoreButton.addActionListener(e -> {
            int selectedRow = archiveTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(dialog, "Please select a user to restore.");
                return;
            }

            String accountCode = model.getValueAt(selectedRow, 0).toString();

            int confirm = JOptionPane.showConfirmDialog(dialog,
                    "Are you sure you want to restore this user?", "Confirm Restore",
                    JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                restoreUser(accountCode);
                model.removeRow(selectedRow); // remove from table after successful restore
            }
        });

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(restoreButton);
        dialog.add(bottomPanel, BorderLayout.SOUTH);

        // Optional table styling
        JTableHeader header = archiveTable.getTableHeader();
        header.setBackground(new Color(96, 125, 139));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Arial", Font.BOLD, 12));
        archiveTable.setRowHeight(28);
        archiveTable.setFont(new Font("Arial", Font.PLAIN, 12));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < archiveTable.getColumnCount(); i++) {
            archiveTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        dialog.setVisible(true);
    }

    private void loadArchivedUsers(DefaultTableModel model) {
    model.setRowCount(0); // clear table
    try (Connection conn = DatabaseConnection.getConnection()) {
        String sql = "SELECT a.account_code, ac.first_name, ac.middle_name, ac.last_name, r.role_name, ac.password, a.date_created, a.date_archived " +
                     "FROM archive_users a " +
                     "JOIN accounts ac ON a.account_code = ac.account_code " +
                     "JOIN roles r ON a.role_id = r.role_id";
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getString("account_code"),
                rs.getString("first_name"),
                rs.getString("middle_name"),
                rs.getString("last_name"),
                rs.getString("role_name"),
                rs.getString("password"),
                rs.getTimestamp("date_created"),
                rs.getTimestamp("date_archived")
            });
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Failed to load archived users: " + e.getMessage());
    }
}
private void restoreUser(String accountCode) {
    try (Connection conn = DatabaseConnection.getConnection()) {
        // Get user from archive
        String selectSQL = "SELECT * FROM archive_users WHERE account_code = ?";
        PreparedStatement selectStmt = conn.prepareStatement(selectSQL);
        selectStmt.setString(1, accountCode);
        ResultSet rs = selectStmt.executeQuery();

        if (rs.next()) {
            int roleId = rs.getInt("role_id");
            Timestamp dateCreated = rs.getTimestamp("date_created");

            // Insert back to users
            String insertSQL = "INSERT INTO users (account_code, role_id, date_created) VALUES (?, ?, ?)";
            PreparedStatement insertStmt = conn.prepareStatement(insertSQL);
            insertStmt.setString(1, accountCode);
            insertStmt.setInt(2, roleId);
            insertStmt.setTimestamp(3, dateCreated);
            insertStmt.executeUpdate();

            // Delete from archive
            String deleteSQL = "DELETE FROM archive_users WHERE account_code = ?";
            PreparedStatement deleteStmt = conn.prepareStatement(deleteSQL);
            deleteStmt.setString(1, accountCode);
            deleteStmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "User restored successfully.");
            populateUsersTable();
        } else {
            JOptionPane.showMessageDialog(this, "User not found in archive.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error restoring user: " + e.getMessage());
    }
}

    public static void main(String args[]) {
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

                try {
                    UIManager.setLookAndFeel(new FlatLightLaf()); // Or FlatIntelliJLaf, FlatDarkLaf
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                // Launch your frame
                SwingUtilities.invokeLater(() -> {
                    new ManageUsers().setVisible(true);
                });
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BrowseButton;
    private javax.swing.JPanel SidebarMenu;
    private javax.swing.JTextField accCodeTextField;
    private javax.swing.JButton add;
    private javax.swing.JButton add1;
    private javax.swing.JButton add2;
    private javax.swing.JButton add3;
    private javax.swing.JTextField firstNameField;
    private javax.swing.JPanel header;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField lastNameField;
    private javax.swing.JTextField middleNameField;
    private javax.swing.JTextField middleNameTextField;
    private javax.swing.JComboBox<String> roleBox;
    private javax.swing.JLabel txtImagePath;
    private javax.swing.JTable usersTable;
    // End of variables declaration//GEN-END:variables

    private void applyShadow(JPanel jPanel1, int i, int i0, int i1, int i2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
