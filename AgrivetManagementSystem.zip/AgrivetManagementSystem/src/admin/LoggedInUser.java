/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package admin;
public class LoggedInUser {
    private static LoggedInUser instance;
    private String fullName;

    // Private constructor to prevent instantiation from outside
    private LoggedInUser() {}

    // Get the single instance of LoggedInUser
    public static LoggedInUser getInstance() {
        if (instance == null) {
            instance = new LoggedInUser();
        }
        return instance;
    }

    // Set the logged-in user's full name
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    // Get the logged-in user's full name
    public String getFullName() {
        return fullName;
    }
}
